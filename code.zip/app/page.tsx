"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import Image from "next/image"

export default function SplashScreen() {
  const [showSplash, setShowSplash] = useState(true)

  useEffect(() => {
    console.log("[v0] SplashScreen component mounted")
    const timer = setTimeout(() => {
      console.log("[v0] Splash screen timeout completed, showing main screen")
      setShowSplash(false)
    }, 1000) // Reduced from 3000ms to 1000ms for faster loading

    return () => clearTimeout(timer)
  }, [])

  if (showSplash) {
    return (
      <div
        className="min-h-screen bg-white flex items-center justify-center p-4"
        style={{ backgroundColor: "white", minHeight: "100vh" }}
      >
        <div className="text-center space-y-8">
          <div className="mx-auto flex items-center justify-center">
            <div className="w-[300px] h-[67px] bg-gray-100 flex items-center justify-center border rounded">
              <Image
                src="/images/tires-pro-logo.png"
                alt="Tires Pro Logo"
                width={300}
                height={67}
                className="max-w-sm w-full h-auto"
                priority
                onError={() => console.log("[v0] Logo image failed to load")}
                onLoad={() => console.log("[v0] Logo image loaded successfully")}
              />
            </div>
          </div>

          <div className="space-y-4">
            <h1 className="text-4xl font-bold text-slate-900">Tires Pro</h1>
            <p className="text-lg text-slate-600 max-w-md mx-auto">
              Gestione professionale del deposito pneumatici stagionali
            </p>
            <p className="text-sm text-slate-500">by BIT Solution</p>
          </div>

          <div className="flex justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-teal-600"></div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div
      className="min-h-screen bg-white flex items-center justify-center p-4"
      style={{ backgroundColor: "white", minHeight: "100vh" }}
    >
      <Card className="w-full max-w-md p-8 space-y-6 bg-white border border-gray-200 shadow-lg">
        <div className="text-center space-y-4">
          <div className="mx-auto flex items-center justify-center">
            <div className="w-[200px] h-[45px] bg-gray-100 flex items-center justify-center border rounded">
              <Image
                src="/images/tires-pro-logo.png"
                alt="Tires Pro Logo"
                width={200}
                height={45}
                className="max-w-xs w-full h-auto"
                onError={() => console.log("[v0] Logo image failed to load in main screen")}
              />
            </div>
          </div>

          <div>
            <h1 className="text-2xl font-bold text-slate-900">Tires Pro</h1>
            <p className="text-slate-600">Sistema di gestione per officine pneumatici</p>
            <p className="text-xs text-slate-500 mt-1">by BIT Solution</p>
          </div>
        </div>

        <div className="space-y-4">
          <Button
            className="w-full h-12 text-lg font-semibold bg-blue-600 hover:bg-blue-700 text-white"
            onClick={() => {
              console.log("[v0] BodyShop login button clicked")
              window.location.href = "/auth/login"
            }}
          >
            Accesso BodyShop
          </Button>

          <Button
            className="w-full h-12 text-lg font-semibold bg-teal-600 hover:bg-teal-700 text-white"
            onClick={() => {
              console.log("[v0] BodyShop register button clicked")
              window.location.href = "/auth/register"
            }}
          >
            Registrati BodyShop
          </Button>

          <Button
            variant="outline"
            className="w-full h-12 text-lg bg-white border-gray-300 text-slate-900 hover:bg-gray-50"
            onClick={() => {
              console.log("[v0] Admin access button clicked")
              window.location.href = "/admin/login"
            }}
          >
            Accesso Amministratore
          </Button>
        </div>

        <div className="text-center text-sm text-slate-600">
          <p>Conforme alle normative italiane per il cambio stagionale</p>
        </div>
      </Card>
    </div>
  )
}
