"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"

interface StoredTire {
  id: number
  client_id: number
  vehicle_id: number
  bodyshop_id: number
  tire_code: string
  brand: string
  size: string
  position: string
  season: string
  dot_code: string
  tread_depth: number
  condition: string
  warehouse_location: string
  status: string
  purchase_price: number
  notes: string
  first_name: string
  last_name: string
  license_plate: string
  make: string
  model: string
  year: number
  created_at: string
}

export default function PneumaticiDepositoPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [seasonFilter, setSeasonFilter] = useState<string>("all")
  const [conditionFilter, setConditionFilter] = useState<string>("all")
  const [locationFilter, setLocationFilter] = useState<string>("all")
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")
  const [bodyshopId, setBodyshopId] = useState<string>("3") // Get from localStorage/auth
  const [storedTires, setStoredTires] = useState<StoredTire[]>([])

  useEffect(() => {
    // Get bodyshop ID from localStorage
    const storedBodyshopId = localStorage.getItem("bodyshopId")
    if (storedBodyshopId) {
      setBodyshopId(storedBodyshopId)
    }
  }, [])

  useEffect(() => {
    if (bodyshopId) {
      fetchStoredTires()
    }
  }, [bodyshopId])

  const fetchStoredTires = async () => {
    try {
      setLoading(true)
      const response = await fetch(`/api/tires?bodyshop_id=${bodyshopId}&status=stored`)
      if (!response.ok) {
        throw new Error("Failed to fetch stored tires")
      }
      const data = await response.json()
      setStoredTires(Array.isArray(data) ? data : [])
    } catch (error) {
      console.error("Error fetching stored tires:", error)
      setError("Errore nel caricamento dei pneumatici in deposito")
      setStoredTires([])
    } finally {
      setLoading(false)
    }
  }

  const filteredTires = storedTires.filter((tire) => {
    const matchesSearch =
      tire.license_plate?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      `${tire.first_name} ${tire.last_name}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tire.tire_code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tire.brand.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesSeason = seasonFilter === "all" || tire.season === seasonFilter
    const matchesCondition = conditionFilter === "all" || tire.condition === conditionFilter
    const matchesLocation = locationFilter === "all" || tire.warehouse_location === locationFilter

    return matchesSearch && matchesSeason && matchesCondition && matchesLocation
  })

  const getUniqueLocations = () => {
    const locations = [...new Set(storedTires.map((tire) => tire.warehouse_location).filter(Boolean))]
    return locations.sort()
  }

  const stats = {
    total: storedTires.length,
    winter: storedTires.filter((tire) => tire.season === "winter").length,
    summer: storedTires.filter((tire) => tire.season === "summer").length,
    excellent: storedTires.filter((tire) => tire.condition === "excellent").length,
    good: storedTires.filter((tire) => tire.condition === "good").length,
  }

  const getSeasonColor = (season: string) => {
    return season === "winter" ? "bg-blue-600 text-white" : "bg-orange-600 text-white"
  }

  const getConditionColor = (condition: string) => {
    switch (condition) {
      case "excellent":
        return "bg-green-100 text-green-800 border-green-300"
      case "good":
        return "bg-blue-100 text-blue-800 border-blue-300"
      case "fair":
        return "bg-yellow-100 text-yellow-800 border-yellow-300"
      case "poor":
        return "bg-red-100 text-red-800 border-red-300"
      default:
        return "bg-gray-100 text-gray-800 border-gray-300"
    }
  }

  const getConditionLabel = (condition: string) => {
    switch (condition) {
      case "excellent":
        return "Eccellente"
      case "good":
        return "Buono"
      case "fair":
        return "Discreto"
      case "poor":
        return "Usurato"
      default:
        return condition
    }
  }

  const getPositionDescription = (position: string): string => {
    const positionMap: { [key: string]: string } = {
      AS: "Anteriore Sinistro",
      AD: "Anteriore Destro",
      PS: "Posteriore Sinistro",
      PD: "Posteriore Destro",
      storage: "Deposito",
    }
    return positionMap[position] || position
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
          <p className="text-green-600">Caricamento pneumatici in deposito...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href="/dashboard">
                <Button
                  variant="outline"
                  size="sm"
                  className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
                >
                  ← Dashboard
                </Button>
              </Link>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center">
                  <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" fill="none" />
                    <circle cx="12" cy="12" r="6" stroke="currentColor" strokeWidth="2" fill="none" />
                    <circle cx="12" cy="12" r="2" fill="currentColor" />
                  </svg>
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900">Pneumatici in Deposito</h1>
                  <p className="text-sm text-gray-600">Gestione pneumatici depositati</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-4">
        {/* Statistics Cards */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
          <Card className="bg-white border-gray-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-gray-900">{stats.total}</div>
              <div className="text-sm text-gray-600">Totale Depositati</div>
            </CardContent>
          </Card>

          <Card className="bg-white border-gray-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">{stats.winter}</div>
              <div className="text-sm text-gray-600">Invernali</div>
            </CardContent>
          </Card>

          <Card className="bg-white border-gray-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-orange-600">{stats.summer}</div>
              <div className="text-sm text-gray-600">Estivi</div>
            </CardContent>
          </Card>

          <Card className="bg-white border-gray-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">{stats.excellent}</div>
              <div className="text-sm text-gray-600">Eccellenti</div>
            </CardContent>
          </Card>

          <Card className="bg-white border-gray-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">{stats.good}</div>
              <div className="text-sm text-gray-600">Buoni</div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <Card className="mb-6 bg-white border-gray-200">
          <CardContent className="p-4 bg-white">
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              <div className="space-y-2">
                <Label htmlFor="search">Cerca</Label>
                <Input
                  id="search"
                  placeholder="Targa, cliente, codice..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="h-10"
                />
              </div>

              <div className="space-y-2">
                <Label>Stagione</Label>
                <Select value={seasonFilter} onValueChange={setSeasonFilter}>
                  <SelectTrigger className="h-10">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tutte</SelectItem>
                    <SelectItem value="winter">Invernali</SelectItem>
                    <SelectItem value="summer">Estivi</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Condizione</Label>
                <Select value={conditionFilter} onValueChange={setConditionFilter}>
                  <SelectTrigger className="h-10">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tutte</SelectItem>
                    <SelectItem value="excellent">Eccellente</SelectItem>
                    <SelectItem value="good">Buono</SelectItem>
                    <SelectItem value="fair">Discreto</SelectItem>
                    <SelectItem value="poor">Usurato</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Posizione</Label>
                <Select value={locationFilter} onValueChange={setLocationFilter}>
                  <SelectTrigger className="h-10">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tutte</SelectItem>
                    {getUniqueLocations().map((location) => (
                      <SelectItem key={location} value={location}>
                        {location}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-end">
                <Button
                  variant="outline"
                  onClick={() => {
                    setSearchTerm("")
                    setSeasonFilter("all")
                    setConditionFilter("all")
                    setLocationFilter("all")
                  }}
                  className="h-10 bg-transparent border-gray-300"
                >
                  Reset Filtri
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Error Message */}
        {error && (
          <Card className="mb-6 border-red-200 bg-red-50">
            <CardContent className="p-4">
              <p className="text-red-600">{error}</p>
            </CardContent>
          </Card>
        )}

        {/* Stored Tires List */}
        <Card className="bg-white border-gray-200">
          <CardHeader className="bg-white">
            <CardTitle className="flex items-center justify-between">
              <span>Pneumatici in Deposito ({filteredTires.length})</span>
              <div className="flex gap-2">
                <Link href="/add-tires">
                  <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white">
                    + Aggiungi Pneumatico
                  </Button>
                </Link>
                <Button
                  variant="outline"
                  size="sm"
                  className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
                >
                  Esporta Excel
                </Button>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="bg-white">
            <div className="space-y-3">
              {filteredTires.length === 0 ? (
                <div className="text-center py-8 text-gray-600">
                  <svg className="w-12 h-12 mx-auto mb-4 opacity-50" fill="currentColor" viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" fill="none" />
                    <circle cx="12" cy="12" r="6" stroke="currentColor" strokeWidth="2" fill="none" />
                    <circle cx="12" cy="12" r="2" fill="currentColor" />
                  </svg>
                  <p>Nessun pneumatico in deposito trovato</p>
                  <p className="text-sm text-gray-500 mt-2">
                    {searchTerm || seasonFilter !== "all" || conditionFilter !== "all" || locationFilter !== "all"
                      ? "Prova a modificare i filtri di ricerca"
                      : "Aggiungi il primo pneumatico al deposito"}
                  </p>
                </div>
              ) : (
                filteredTires.map((tire) => (
                  <Card
                    key={tire.id}
                    className="cursor-pointer transition-all hover:shadow-md bg-white border-gray-200"
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="space-y-2">
                          <div className="flex items-center gap-3">
                            <Badge className={`font-mono ${getSeasonColor(tire.season)}`}>
                              {tire.license_plate || "N/A"}
                            </Badge>
                            <span className="font-semibold">
                              {tire.first_name} {tire.last_name}
                            </span>
                            <Badge variant="outline" className={getConditionColor(tire.condition)}>
                              {getConditionLabel(tire.condition)}
                            </Badge>
                            <Badge variant="outline" className="text-xs">
                              {tire.season === "winter" ? "❄️ Invernali" : "☀️ Estivi"}
                            </Badge>
                          </div>

                          <div className="text-sm text-gray-600">
                            <span className="font-medium">{tire.brand}</span> • {tire.size} • Codice: {tire.tire_code} •
                            Posizione: {getPositionDescription(tire.position)} • Magazzino: {tire.warehouse_location}
                          </div>

                          <div className="flex items-center gap-4 text-xs text-gray-600">
                            <span>
                              Veicolo: {tire.make} {tire.model} ({tire.year})
                            </span>
                            <span>Battistrada: {tire.tread_depth}mm</span>
                            {tire.dot_code && <span>DOT: {tire.dot_code}</span>}
                            {tire.purchase_price && <span>Prezzo: €{tire.purchase_price}</span>}
                          </div>

                          <div className="text-xs text-gray-500">
                            Depositato il: {new Date(tire.created_at).toLocaleDateString("it-IT")}
                          </div>

                          {tire.notes && (
                            <div className="text-xs text-blue-600 bg-blue-50 px-2 py-1 rounded">Note: {tire.notes}</div>
                          )}
                        </div>

                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
                          >
                            Modifica
                          </Button>
                          <Button variant="outline" size="sm" className="text-blue-600 border-blue-300 bg-transparent">
                            Ritira
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-green-600 border-green-300 bg-transparent"
                          >
                            Installa
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
