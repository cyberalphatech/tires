"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"

interface InventoryItem {
  id: number
  client_id: number
  vehicle_id: number
  tire_code: string
  brand: string
  size: string
  position: string
  season: string
  dot_code: string
  manufacture_year: number
  tread_depth: number
  condition_rating: string
  warehouse_location: string
  status: string
  first_name: string
  last_name: string
  license_plate: string
  make: string
  model: string
  year: number
  created_at: string
}

interface InventorySummary {
  season: string
  status: string
  warehouse_location: string
  count: number
  avg_tread_depth: number
  brands: string
}

export default function InventoryPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [seasonFilter, setSeasonFilter] = useState<string>("all")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [locationFilter, setLocationFilter] = useState<string>("all")
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")
  const [bodyshopId, setBodyshopId] = useState<string>("1") // This should come from auth context

  const [inventoryData, setInventoryData] = useState<{
    summary: InventorySummary[]
    detailed: InventoryItem[]
  }>({
    summary: [],
    detailed: [],
  })

  useEffect(() => {
    fetchInventoryData()
  }, [bodyshopId])

  const fetchInventoryData = async () => {
    try {
      setLoading(true)
      const response = await fetch(`/api/bodyshop/${bodyshopId}/inventory`)
      if (!response.ok) {
        throw new Error("Failed to fetch inventory data")
      }
      const data = await response.json()
      setInventoryData(data)
    } catch (error) {
      console.error("Error fetching inventory:", error)
      setError("Errore nel caricamento dell'inventario")
    } finally {
      setLoading(false)
    }
  }

  const filteredInventory = inventoryData.detailed.filter((item) => {
    const matchesSearch =
      item.license_plate?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      `${item.first_name} ${item.last_name}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.tire_code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.brand.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesSeason = seasonFilter === "all" || item.season === seasonFilter
    const matchesStatus = statusFilter === "all" || item.status === statusFilter
    const matchesLocation = locationFilter === "all" || item.warehouse_location === locationFilter

    return matchesSearch && matchesSeason && matchesStatus && matchesLocation
  })

  const getUniqueLocations = () => {
    const locations = [...new Set(inventoryData.detailed.map((item) => item.warehouse_location).filter(Boolean))]
    return locations.sort()
  }

  const stats = {
    total: inventoryData.detailed.length,
    stored: inventoryData.detailed.filter((item) => item.status === "stored").length,
    inUse: inventoryData.detailed.filter((item) => item.status === "in_use").length,
    winter: inventoryData.detailed.filter((item) => item.season === "winter" && item.status === "stored").length,
    summer: inventoryData.detailed.filter((item) => item.season === "summer" && item.status === "stored").length,
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "stored":
        return "bg-green-100 text-green-800 border-green-300"
      case "in_use":
        return "bg-blue-100 text-blue-800 border-blue-300"
      case "scrapped":
        return "bg-red-100 text-red-800 border-red-300"
      default:
        return "bg-gray-100 text-gray-800 border-gray-300"
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "stored":
        return "Depositato"
      case "in_use":
        return "In Uso"
      case "scrapped":
        return "Rottamato"
      default:
        return status
    }
  }

  const getSeasonColor = (season: string) => {
    return season === "winter" ? "bg-blue-600 text-white" : "bg-orange-600 text-white"
  }

  const getPositionDescription = (position: string): string => {
    const positionMap: { [key: string]: string } = {
      AS: "Anteriore Sinistro",
      AD: "Anteriore Destro",
      PS: "Posteriore Sinistro",
      PD: "Posteriore Destro",
      ET: "Extra Tire",
      A6: "Anteriore Sinistro",
      A5: "Anteriore Destro",
      P6: "Posteriore Sinistro",
      P4: "Posteriore Destro",
    }
    return positionMap[position] || position
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
          <p className="text-green-600">Caricamento inventario...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href="/dashboard">
                <Button
                  variant="outline"
                  size="sm"
                  className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
                >
                  ← Dashboard
                </Button>
              </Link>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center">
                  <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M19 3H5C3.9 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V5C21 3.9 20.1 3 19 3ZM19 19H5V5H19V19ZM17 12H15V17H17V12ZM13 7H11V17H13V7ZM9 10H7V17H9V10Z" />
                  </svg>
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900">Gestione Inventario</h1>
                  <p className="text-sm text-gray-600">Inventario completo pneumatici</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-4">
        {/* Statistics Cards */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
          <Card className="bg-white border-gray-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-gray-900">{stats.total}</div>
              <div className="text-sm text-gray-600">Totale Pneumatici</div>
            </CardContent>
          </Card>

          <Card className="bg-white border-gray-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">{stats.stored}</div>
              <div className="text-sm text-gray-600">Depositati</div>
            </CardContent>
          </Card>

          <Card className="bg-white border-gray-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">{stats.winter}</div>
              <div className="text-sm text-gray-600">Invernali</div>
            </CardContent>
          </Card>

          <Card className="bg-white border-gray-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-orange-600">{stats.summer}</div>
              <div className="text-sm text-gray-600">Estivi</div>
            </CardContent>
          </Card>

          <Card className="bg-white border-gray-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">{stats.inUse}</div>
              <div className="text-sm text-gray-600">In Uso</div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <Card className="mb-6 bg-white border-gray-200">
          <CardContent className="p-4 bg-white">
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              <div className="space-y-2">
                <Label htmlFor="search">Cerca</Label>
                <Input
                  id="search"
                  placeholder="Targa, cliente, codice..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="h-10"
                />
              </div>

              <div className="space-y-2">
                <Label>Stagione</Label>
                <Select value={seasonFilter} onValueChange={setSeasonFilter}>
                  <SelectTrigger className="h-10">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tutte</SelectItem>
                    <SelectItem value="winter">Invernali</SelectItem>
                    <SelectItem value="summer">Estivi</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Stato</Label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="h-10">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tutti</SelectItem>
                    <SelectItem value="stored">Depositato</SelectItem>
                    <SelectItem value="in_use">In Uso</SelectItem>
                    <SelectItem value="scrapped">Rottamato</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Posizione</Label>
                <Select value={locationFilter} onValueChange={setLocationFilter}>
                  <SelectTrigger className="h-10">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tutte</SelectItem>
                    {getUniqueLocations().map((location) => (
                      <SelectItem key={location} value={location}>
                        {location}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-end">
                <Button
                  variant="outline"
                  onClick={() => {
                    setSearchTerm("")
                    setSeasonFilter("all")
                    setStatusFilter("all")
                    setLocationFilter("all")
                  }}
                  className="h-10 bg-transparent border-gray-300"
                >
                  Reset Filtri
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Error Message */}
        {error && (
          <Card className="mb-6 border-red-200 bg-red-50">
            <CardContent className="p-4">
              <p className="text-red-600">{error}</p>
            </CardContent>
          </Card>
        )}

        {/* Inventory List */}
        <Card className="bg-white border-gray-200">
          <CardHeader className="bg-white">
            <CardTitle className="flex items-center justify-between">
              <span>Inventario Pneumatici ({filteredInventory.length})</span>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
                >
                  Esporta Excel
                </Button>
                <Button size="sm" className="bg-gray-600 hover:bg-gray-700 text-white">
                  Stampa Etichette
                </Button>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="bg-white">
            <div className="space-y-3">
              {filteredInventory.length === 0 ? (
                <div className="text-center py-8 text-gray-600">
                  <svg className="w-12 h-12 mx-auto mb-4 opacity-50" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M19 3H5C3.9 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V5C21 3.9 20.1 3 19 3ZM19 19H5V5H19V19ZM17 12H15V17H17V12ZM13 7H11V17H13V7ZM9 10H7V17H9V10Z" />
                  </svg>
                  <p>Nessun pneumatico trovato con i filtri selezionati</p>
                </div>
              ) : (
                filteredInventory.map((item) => (
                  <Card
                    key={item.id}
                    className="cursor-pointer transition-all hover:shadow-md bg-white border-gray-200"
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="space-y-2">
                          <div className="flex items-center gap-3">
                            <Badge className={`font-mono ${getSeasonColor(item.season)}`}>
                              {item.license_plate || "N/A"}
                            </Badge>
                            <span className="font-semibold">
                              {item.first_name} {item.last_name}
                            </span>
                            <Badge variant="outline" className={getStatusColor(item.status)}>
                              {getStatusLabel(item.status)}
                            </Badge>
                            <Badge variant="outline" className="text-xs">
                              {item.season === "winter" ? "❄️ Invernali" : "☀️ Estivi"}
                            </Badge>
                          </div>

                          <div className="text-sm text-gray-600">
                            <span className="font-medium">{item.brand}</span> • {item.size} • Codice: {item.tire_code} •
                            Posizione: {getPositionDescription(item.position)} • Magazzino: {item.warehouse_location}
                          </div>

                          <div className="flex items-center gap-4 text-xs text-gray-600">
                            <span>
                              Veicolo: {item.make} {item.model} ({item.year})
                            </span>
                            <span>Battistrada: {item.tread_depth}mm</span>
                            <span>Condizione: {item.condition_rating}</span>
                            <span>DOT: {item.dot_code}</span>
                            <span>Anno: {item.manufacture_year}</span>
                          </div>

                          <div className="text-xs text-gray-500">
                            Depositato il: {new Date(item.created_at).toLocaleDateString("it-IT")}
                          </div>
                        </div>

                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
                          >
                            Modifica
                          </Button>
                          {item.status === "stored" && (
                            <Button
                              variant="outline"
                              size="sm"
                              className="text-blue-600 border-blue-300 bg-transparent"
                            >
                              Ritira
                            </Button>
                          )}
                          {item.status === "in_use" && (
                            <Button
                              variant="outline"
                              size="sm"
                              className="text-green-600 border-green-300 bg-transparent"
                            >
                              Deposita
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
