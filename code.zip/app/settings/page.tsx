"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Warehouse, CreditCard, Settings } from "lucide-react"
import { useRouter } from "next/navigation"

export default function SettingsPage() {
  const router = useRouter()

  const settingsItems = [
    {
      id: "warehouse",
      title: "Magazzino Setup",
      description: "Configura le impostazioni del magazzino e delle posizioni",
      icon: Warehouse,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      href: "/settings/warehouse",
    },
    {
      id: "subscription",
      title: "Abbonamento",
      description: "Gestisci il tuo piano di abbonamento e fatturazione",
      icon: CreditCard,
      color: "text-green-600",
      bgColor: "bg-green-50",
      href: "/settings/subscription",
    },
  ]

  return (
    <div className="min-h-screen bg-white p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="outline"
            size="sm"
            onClick={() => router.back()}
            className="bg-white border-gray-300 text-gray-700 hover:bg-gray-50"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Indietro
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <Settings className="h-8 w-8 text-gray-600" />
              Impostazioni
            </h1>
            <p className="text-gray-600 mt-1">Configura le impostazioni del sistema</p>
          </div>
        </div>

        {/* Settings Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {settingsItems.map((item) => {
            const IconComponent = item.icon
            return (
              <Card
                key={item.id}
                className="bg-white border border-gray-200 hover:shadow-lg transition-shadow cursor-pointer"
                onClick={() => router.push(item.href)}
              >
                <CardHeader className="pb-4">
                  <div className={`w-12 h-12 rounded-lg ${item.bgColor} flex items-center justify-center mb-4`}>
                    <IconComponent className={`h-6 w-6 ${item.color}`} />
                  </div>
                  <CardTitle className="text-xl text-gray-900">{item.title}</CardTitle>
                  <CardDescription className="text-gray-600">{item.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button
                    className="w-full bg-gray-600 hover:bg-gray-700 text-white"
                    onClick={(e) => {
                      e.stopPropagation()
                      router.push(item.href)
                    }}
                  >
                    Configura
                  </Button>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>
    </div>
  )
}
