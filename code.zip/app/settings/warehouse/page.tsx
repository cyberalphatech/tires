"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Warehouse } from "lucide-react"
import { useRouter } from "next/navigation"

export default function WarehouseSettingsPage() {
  const router = useRouter()

  return (
    <div className="min-h-screen bg-white p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="outline"
            size="sm"
            onClick={() => router.back()}
            className="bg-white border-gray-300 text-gray-700 hover:bg-gray-50"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Indietro
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <Warehouse className="h-8 w-8 text-blue-600" />
              Magazzino Setup
            </h1>
            <p className="text-gray-600 mt-1">Configura le impostazioni del magazzino</p>
          </div>
        </div>

        {/* Warehouse Settings Content */}
        <Card className="bg-white border border-gray-200">
          <CardHeader>
            <CardTitle className="text-xl text-gray-900">Configurazione Magazzino</CardTitle>
            <CardDescription className="text-gray-600">
              Imposta le posizioni e le configurazioni del tuo magazzino
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center py-12">
              <Warehouse className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Configurazione Magazzino</h3>
              <p className="text-gray-600 mb-6">
                Questa sezione sarà disponibile a breve per configurare le impostazioni del magazzino.
              </p>
              <div className="flex gap-4 justify-center">
                <Button
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                  onClick={() => router.push("/settings/warehouse/positions")}
                >
                  Configura Posizioni
                </Button>
                <Button
                  className="bg-green-600 hover:bg-green-700 text-white"
                  onClick={() => router.push("/settings/warehouse/visual")}
                >
                  Vista Grafica Magazzino
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
