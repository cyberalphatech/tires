"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, Plus, Edit, Trash2, Package, Upload, Download } from "lucide-react"
import { useRouter } from "next/navigation"

interface WarehousePosition {
  id: number
  scaffale: string
  area: string
  livello: string
  posizione: string
  position_code: string
  description: string
  is_active: boolean
}

export default function WarehousePositionsPage() {
  const router = useRouter()
  const [positions, setPositions] = useState<WarehousePosition[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editingPosition, setEditingPosition] = useState<WarehousePosition | null>(null)
  const [bodyshopId, setBodyshopId] = useState<string>("")
  const [importing, setImporting] = useState(false)
  const [importResults, setImportResults] = useState<{ success: number; errors: string[] } | null>(null)

  const [formData, setFormData] = useState({
    scaffale: "",
    area: "",
    livello: "",
    posizione: "",
    description: "",
  })

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      const user = JSON.parse(userData)
      setBodyshopId(user.id?.toString() || "")
      fetchPositions(user.id?.toString() || "")
    }
  }, [])

  const fetchPositions = async (bodyshopId: string) => {
    try {
      const response = await fetch(`/api/warehouse/positions?bodyshop_id=${bodyshopId}`)
      const data = await response.json()
      setPositions(data.positions || [])
    } catch (error) {
      console.error("Error fetching positions:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      const url = editingPosition ? `/api/warehouse/positions/${editingPosition.id}` : "/api/warehouse/positions"

      const method = editingPosition ? "PUT" : "POST"

      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...formData,
          bodyshop_id: bodyshopId,
        }),
      })

      if (response.ok) {
        fetchPositions(bodyshopId)
        setShowForm(false)
        setEditingPosition(null)
        setFormData({ scaffale: "", area: "", livello: "", posizione: "", description: "" })
      }
    } catch (error) {
      console.error("Error saving position:", error)
    }
  }

  const handleEdit = (position: WarehousePosition) => {
    setEditingPosition(position)
    setFormData({
      scaffale: position.scaffale,
      area: position.area,
      livello: position.livello,
      posizione: position.posizione,
      description: position.description,
    })
    setShowForm(true)
  }

  const handleDelete = async (id: number) => {
    if (confirm("Sei sicuro di voler eliminare questa posizione?")) {
      try {
        await fetch(`/api/warehouse/positions/${id}`, { method: "DELETE" })
        fetchPositions(bodyshopId)
      } catch (error) {
        console.error("Error deleting position:", error)
      }
    }
  }

  const handleExcelImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    setImporting(true)
    setImportResults(null)

    const formData = new FormData()
    formData.append("file", file)
    formData.append("bodyshop_id", bodyshopId)

    try {
      const response = await fetch("/api/warehouse/positions/import", {
        method: "POST",
        body: formData,
      })

      const result = await response.json()

      if (response.ok) {
        setImportResults(result)
        fetchPositions(bodyshopId)
      } else {
        setImportResults({ success: 0, errors: [result.error || "Errore durante l'importazione"] })
      }
    } catch (error) {
      console.error("Error importing Excel:", error)
      setImportResults({ success: 0, errors: ["Errore di connessione durante l'importazione"] })
    } finally {
      setImporting(false)
      // Reset file input
      event.target.value = ""
    }
  }

  const downloadTemplate = () => {
    const csvContent =
      "scaffale,area,livello,posizione,description\n01,01,01,01,Esempio posizione 1\n01,01,01,02,Esempio posizione 2\n01,01,02,01,Esempio posizione 3"
    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "template_posizioni_magazzino.csv"
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    window.URL.revokeObjectURL(url)
  }

  return (
    <div className="min-h-screen bg-white p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              onClick={() => router.back()}
              className="bg-white border-gray-300 text-gray-700 hover:bg-gray-50"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Indietro
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Configurazione Posizioni</h1>
              <p className="text-gray-600">Gestisci le posizioni del magazzino</p>
            </div>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={downloadTemplate}
              className="bg-white border-gray-300 text-gray-700 hover:bg-gray-50"
            >
              <Download className="w-4 h-4 mr-2" />
              Template Excel
            </Button>
            <div className="relative">
              <input
                type="file"
                accept=".xlsx,.xls,.csv"
                onChange={handleExcelImport}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                disabled={importing}
              />
              <Button
                variant="outline"
                disabled={importing}
                className="bg-white border-gray-300 text-gray-700 hover:bg-gray-50"
              >
                <Upload className="w-4 h-4 mr-2" />
                {importing ? "Importando..." : "Importa Excel"}
              </Button>
            </div>
            <Button onClick={() => setShowForm(true)} className="bg-gray-900 text-white hover:bg-gray-800">
              <Plus className="w-4 h-4 mr-2" />
              Nuova Posizione
            </Button>
          </div>
        </div>

        {importResults && (
          <Card className="mb-6 bg-white border-gray-200">
            <CardHeader>
              <CardTitle className="text-gray-900">Risultati Importazione</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="text-green-600">✓ {importResults.success} posizioni importate con successo</div>
                {importResults.errors.length > 0 && (
                  <div className="space-y-1">
                    <div className="text-red-600 font-medium">Errori:</div>
                    {importResults.errors.map((error, index) => (
                      <div key={index} className="text-red-600 text-sm">
                        • {error}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Reference Image */}
        <Card className="mb-6 bg-white border-gray-200">
          <CardHeader>
            <CardTitle className="text-gray-900">Riferimento Layout Magazzino</CardTitle>
          </CardHeader>
          <CardContent>
            <img
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image.png-w4ypgJWFGzwBliGouGTVlcjXeLO6Vv.jpeg"
              alt="Warehouse Layout Reference"
              className="w-full max-w-4xl mx-auto rounded-lg border border-gray-200"
            />
          </CardContent>
        </Card>

        {/* Form */}
        {showForm && (
          <Card className="mb-6 bg-white border-gray-200">
            <CardHeader>
              <CardTitle className="text-gray-900">
                {editingPosition ? "Modifica Posizione" : "Nuova Posizione"}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <Label htmlFor="scaffale" className="text-gray-700">
                    Scaffale
                  </Label>
                  <Input
                    id="scaffale"
                    value={formData.scaffale}
                    onChange={(e) => setFormData({ ...formData, scaffale: e.target.value })}
                    placeholder="01"
                    className="bg-white border-gray-300 text-gray-900"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="area" className="text-gray-700">
                    Area
                  </Label>
                  <Input
                    id="area"
                    value={formData.area}
                    onChange={(e) => setFormData({ ...formData, area: e.target.value })}
                    placeholder="01"
                    className="bg-white border-gray-300 text-gray-900"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="livello" className="text-gray-700">
                    Livello
                  </Label>
                  <Input
                    id="livello"
                    value={formData.livello}
                    onChange={(e) => setFormData({ ...formData, livello: e.target.value })}
                    placeholder="01"
                    className="bg-white border-gray-300 text-gray-900"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="posizione" className="text-gray-700">
                    Posizione
                  </Label>
                  <Input
                    id="posizione"
                    value={formData.posizione}
                    onChange={(e) => setFormData({ ...formData, posizione: e.target.value })}
                    placeholder="03"
                    className="bg-white border-gray-300 text-gray-900"
                    required
                  />
                </div>
                <div className="md:col-span-4">
                  <Label htmlFor="description" className="text-gray-700">
                    Descrizione
                  </Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Descrizione opzionale della posizione"
                    className="bg-white border-gray-300 text-gray-900"
                  />
                </div>
                <div className="md:col-span-4 flex gap-2">
                  <Button type="submit" className="bg-gray-900 text-white hover:bg-gray-800">
                    {editingPosition ? "Aggiorna" : "Crea"} Posizione
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setShowForm(false)
                      setEditingPosition(null)
                      setFormData({ scaffale: "", area: "", livello: "", posizione: "", description: "" })
                    }}
                    className="bg-white border-gray-300 text-gray-700 hover:bg-gray-50"
                  >
                    Annulla
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Positions List */}
        <Card className="bg-white border-gray-200">
          <CardHeader>
            <CardTitle className="text-gray-900">Posizioni Configurate</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8 text-gray-600">Caricamento posizioni...</div>
            ) : positions.length === 0 ? (
              <div className="text-center py-8 text-gray-600">Nessuna posizione configurata</div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {positions.map((position) => (
                  <div key={position.id} className="border border-gray-200 rounded-lg p-4 bg-gray-50">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Package className="w-4 h-4 text-gray-600" />
                        <span className="font-mono text-lg font-bold text-gray-900">{position.position_code}</span>
                      </div>
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleEdit(position)}
                          className="bg-white border-gray-300 text-gray-700 hover:bg-gray-50"
                        >
                          <Edit className="w-3 h-3" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDelete(position.id)}
                          className="bg-white border-gray-300 text-red-600 hover:bg-red-50"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                    <div className="text-sm text-gray-600 space-y-1">
                      <div>Scaffale: {position.scaffale}</div>
                      <div>Area: {position.area}</div>
                      <div>Livello: {position.livello}</div>
                      <div>Posizione: {position.posizione}</div>
                      {position.description && <div className="mt-2 text-gray-700">{position.description}</div>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
