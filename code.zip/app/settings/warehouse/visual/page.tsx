"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Warehouse, Package, AlertCircle } from "lucide-react"
import { useRouter } from "next/navigation"
import { useState, useEffect } from "react"

interface WarehousePosition {
  id: number
  scaffale: string
  area: string
  livello: string
  posizione: string
  position_code: string
  description: string
  is_active: boolean
  occupied: boolean
  tire_count: number
  client_name?: string
}

export default function WarehouseVisualPage() {
  const router = useRouter()
  const [positions, setPositions] = useState<WarehousePosition[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedPosition, setSelectedPosition] = useState<WarehousePosition | null>(null)

  useEffect(() => {
    fetchWarehouseData()
  }, [])

  const fetchWarehouseData = async () => {
    try {
      // Get bodyshop ID from localStorage
      const userData = localStorage.getItem("user")
      if (!userData) {
        console.error("No user data found")
        setLoading(false)
        return
      }

      const user = JSON.parse(userData)
      const bodyshopId = user.id

      console.log("[v0] Fetching warehouse data for bodyshop:", bodyshopId)

      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 10000) // 10 second timeout

      const response = await fetch(`/api/warehouse/positions/visual/${bodyshopId}`, {
        signal: controller.signal,
      })

      clearTimeout(timeoutId)

      if (response.ok) {
        const data = await response.json()
        console.log("[v0] Received warehouse data:", data.length, "positions")
        setPositions(data || [])
      } else {
        console.error("[v0] API response not ok:", response.status)
        setPositions([])
      }
    } catch (error) {
      console.error("[v0] Error fetching warehouse data:", error)
      setPositions([])
    } finally {
      setLoading(false)
    }
  }

  const groupPositionsByScaffale = () => {
    const grouped: { [key: string]: WarehousePosition[] } = {}
    positions.forEach((position) => {
      const key = `${position.scaffale}-${position.area}`
      if (!grouped[key]) {
        grouped[key] = []
      }
      grouped[key].push(position)
    })
    return grouped
  }

  const getPositionColor = (position: WarehousePosition) => {
    if (!position.is_active) return "bg-gray-300 border-gray-400"
    if (position.occupied) return "bg-red-500 border-red-600 hover:bg-red-600"
    return "bg-green-500 border-green-600 hover:bg-green-600"
  }

  const getPositionIcon = (position: WarehousePosition) => {
    if (!position.is_active) return <AlertCircle className="h-4 w-4 text-gray-600" />
    if (position.occupied) return <Package className="h-4 w-4 text-white" />
    return <div className="h-4 w-4" />
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-white p-4 flex items-center justify-center">
        <div className="text-center">
          <Warehouse className="h-12 w-12 text-blue-600 mx-auto mb-4 animate-pulse" />
          <p className="text-gray-600">Caricamento vista magazzino...</p>
        </div>
      </div>
    )
  }

  const groupedPositions = groupPositionsByScaffale()
  const totalPositions = positions.length
  const occupiedPositions = positions.filter((p) => p.occupied).length
  const availablePositions = positions.filter((p) => !p.occupied && p.is_active).length

  return (
    <div className="min-h-screen bg-white p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="outline"
            size="sm"
            onClick={() => router.back()}
            className="bg-white border-gray-300 text-gray-700 hover:bg-gray-50"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Indietro
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <Warehouse className="h-8 w-8 text-blue-600" />
              Vista Grafica Magazzino
            </h1>
            <p className="text-gray-600 mt-1">Visualizza la disponibilità delle posizioni in tempo reale</p>
          </div>
        </div>

        {/* Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="bg-white border border-gray-200">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <Warehouse className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Posizioni Totali</p>
                  <p className="text-2xl font-bold text-gray-900">{totalPositions}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white border border-gray-200">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-green-100 rounded-lg">
                  <div className="h-5 w-5 bg-green-500 rounded"></div>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Disponibili</p>
                  <p className="text-2xl font-bold text-green-600">{availablePositions}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white border border-gray-200">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-red-100 rounded-lg">
                  <div className="h-5 w-5 bg-red-500 rounded"></div>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Occupate</p>
                  <p className="text-2xl font-bold text-red-600">{occupiedPositions}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white border border-gray-200">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-gray-100 rounded-lg">
                  <AlertCircle className="h-5 w-5 text-gray-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Occupazione</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {totalPositions > 0 ? Math.round((occupiedPositions / totalPositions) * 100) : 0}%
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Legend */}
        <Card className="bg-white border border-gray-200 mb-6">
          <CardContent className="p-4">
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-green-500 border border-green-600 rounded"></div>
                <span className="text-sm text-gray-700">Disponibile</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-red-500 border border-red-600 rounded"></div>
                <span className="text-sm text-gray-700">Occupata</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-gray-300 border border-gray-400 rounded"></div>
                <span className="text-sm text-gray-700">Non Attiva</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Warehouse Grid */}
        <div className="grid gap-6">
          {Object.entries(groupedPositions).map(([scaffaleArea, positionList]) => (
            <Card key={scaffaleArea} className="bg-white border border-gray-200">
              <CardHeader>
                <CardTitle className="text-lg text-gray-900">
                  Scaffale {scaffaleArea.split("-")[0]} - Area {scaffaleArea.split("-")[1]}
                </CardTitle>
                <CardDescription>
                  {positionList.filter((p) => p.occupied).length} occupate di {positionList.length} posizioni
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-8 md:grid-cols-12 lg:grid-cols-16 gap-2">
                  {positionList
                    .sort((a, b) => {
                      if (a.livello !== b.livello) return a.livello.localeCompare(b.livello)
                      return a.posizione.localeCompare(b.posizione)
                    })
                    .map((position) => (
                      <button
                        key={position.id}
                        className={`
                          relative w-12 h-12 rounded border-2 transition-all duration-200 cursor-pointer
                          flex items-center justify-center text-xs font-medium
                          ${getPositionColor(position)}
                        `}
                        onClick={() => setSelectedPosition(position)}
                        title={`${position.position_code} - ${position.occupied ? "Occupata" : "Disponibile"}`}
                      >
                        {getPositionIcon(position)}
                        <div className="absolute -bottom-6 left-0 right-0 text-xs text-gray-600 text-center">
                          {position.livello}-{position.posizione}
                        </div>
                      </button>
                    ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Position Details Modal */}
        {selectedPosition && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <Card className="bg-white max-w-md w-full">
              <CardHeader>
                <CardTitle className="text-lg text-gray-900">Posizione {selectedPosition.position_code}</CardTitle>
                <CardDescription>Dettagli della posizione selezionata</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-600">Scaffale</p>
                    <p className="font-medium text-gray-900">{selectedPosition.scaffale}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Area</p>
                    <p className="font-medium text-gray-900">{selectedPosition.area}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Livello</p>
                    <p className="font-medium text-gray-900">{selectedPosition.livello}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Posizione</p>
                    <p className="font-medium text-gray-900">{selectedPosition.posizione}</p>
                  </div>
                </div>

                <div>
                  <p className="text-sm text-gray-600">Stato</p>
                  <div className="flex items-center gap-2 mt-1">
                    <div className={`w-3 h-3 rounded ${getPositionColor(selectedPosition)}`}></div>
                    <p className="font-medium text-gray-900">
                      {!selectedPosition.is_active
                        ? "Non Attiva"
                        : selectedPosition.occupied
                          ? "Occupata"
                          : "Disponibile"}
                    </p>
                  </div>
                </div>

                {selectedPosition.occupied && (
                  <>
                    <div>
                      <p className="text-sm text-gray-600">Pneumatici</p>
                      <p className="font-medium text-gray-900">{selectedPosition.tire_count} set</p>
                    </div>
                    {selectedPosition.client_name && (
                      <div>
                        <p className="text-sm text-gray-600">Cliente</p>
                        <p className="font-medium text-gray-900">{selectedPosition.client_name}</p>
                      </div>
                    )}
                  </>
                )}

                <div>
                  <p className="text-sm text-gray-600">Descrizione</p>
                  <p className="font-medium text-gray-900">{selectedPosition.description || "Nessuna descrizione"}</p>
                </div>

                <Button
                  className="w-full bg-gray-600 hover:bg-gray-700 text-white"
                  onClick={() => setSelectedPosition(null)}
                >
                  Chiudi
                </Button>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
