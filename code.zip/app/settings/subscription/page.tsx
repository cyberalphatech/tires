"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, CreditCard } from "lucide-react"
import { useRouter } from "next/navigation"

export default function SubscriptionSettingsPage() {
  const router = useRouter()

  return (
    <div className="min-h-screen bg-white p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="outline"
            size="sm"
            onClick={() => router.back()}
            className="bg-white border-gray-300 text-gray-700 hover:bg-gray-50"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Indietro
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <CreditCard className="h-8 w-8 text-green-600" />
              Abbonamento
            </h1>
            <p className="text-gray-600 mt-1">Gestisci il tuo piano di abbonamento</p>
          </div>
        </div>

        {/* Subscription Settings Content */}
        <Card className="bg-white border border-gray-200">
          <CardHeader>
            <CardTitle className="text-xl text-gray-900">Piano Abbonamento</CardTitle>
            <CardDescription className="text-gray-600">
              Visualizza e gestisci il tuo piano di abbonamento attuale
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center py-12">
              <CreditCard className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Gestione Abbonamento</h3>
              <p className="text-gray-600 mb-6">
                Questa sezione sarà disponibile a breve per gestire il tuo abbonamento e la fatturazione.
              </p>
              <Button className="bg-green-600 hover:bg-green-700 text-white">Visualizza Piano</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
