"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Link from "next/link"
import { useParams, useRouter } from "next/navigation"

interface VehicleData {
  licensePlate: string
  make: string
  model: string
  year: string
  vin: string
  totalKm: string
  fuelType: string
  engineSize: string
  color: string
  notes: string
  images: string[]
}

export default function AddVehicle() {
  const params = useParams()
  const router = useRouter()
  const customerId = params.id as string

  const [vehicleData, setVehicleData] = useState<VehicleData>({
    licensePlate: "",
    make: "",
    model: "",
    year: "",
    vin: "",
    totalKm: "",
    fuelType: "",
    engineSize: "",
    color: "",
    notes: "",
    images: [],
  })

  const [imageFiles, setImageFiles] = useState<File[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleInputChange = (field: keyof VehicleData, value: string) => {
    setVehicleData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    if (files.length > 0) {
      setImageFiles((prev) => [...prev, ...files].slice(0, 6)) // Max 6 images

      // Convert to base64 for preview
      files.forEach((file) => {
        const reader = new FileReader()
        reader.onload = (e) => {
          const result = e.target?.result as string
          setVehicleData((prev) => ({
            ...prev,
            images: [...prev.images, result].slice(0, 6),
          }))
        }
        reader.readAsDataURL(file)
      })
    }
  }

  const removeImage = (index: number) => {
    setVehicleData((prev) => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index),
    }))
    setImageFiles((prev) => prev.filter((_, i) => i !== index))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      // Generate vehicle ID
      const vehicleId = Date.now().toString()

      // Save vehicle data to localStorage
      const vehicleWithId = {
        ...vehicleData,
        id: vehicleId,
        customerId,
        createdAt: new Date().toISOString(),
      }

      // Get existing vehicles for this customer
      const existingVehicles = JSON.parse(localStorage.getItem(`vehicles_${customerId}`) || "[]")
      existingVehicles.push(vehicleWithId)
      localStorage.setItem(`vehicles_${customerId}`, JSON.stringify(existingVehicles))

      // Redirect back to customer dashboard
      router.push(`/customer/${customerId}/dashboard`)
    } catch (error) {
      console.error("Error saving vehicle:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center gap-3">
            <Link href={`/customer/${customerId}/dashboard`}>
              <Button variant="outline" size="sm">
                ← Indietro
              </Button>
            </Link>
            <div>
              <h1 className="text-xl font-bold text-gray-800">Aggiungi Veicolo</h1>
              <p className="text-sm text-muted-foreground">Registra un nuovo veicolo per il cliente</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto p-4">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Vehicle Information */}
          <Card className="bg-white">
            <CardHeader>
              <CardTitle className="text-gray-800">Informazioni Veicolo</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="licensePlate">Targa *</Label>
                  <Input
                    id="licensePlate"
                    value={vehicleData.licensePlate}
                    onChange={(e) => handleInputChange("licensePlate", e.target.value.toUpperCase())}
                    placeholder="AB123CD"
                    className="uppercase"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="totalKm">Chilometraggio Totale *</Label>
                  <Input
                    id="totalKm"
                    type="number"
                    value={vehicleData.totalKm}
                    onChange={(e) => handleInputChange("totalKm", e.target.value)}
                    placeholder="150000"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="make">Marca *</Label>
                  <Input
                    id="make"
                    value={vehicleData.make}
                    onChange={(e) => handleInputChange("make", e.target.value)}
                    placeholder="Fiat, BMW, Mercedes..."
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="model">Modello *</Label>
                  <Input
                    id="model"
                    value={vehicleData.model}
                    onChange={(e) => handleInputChange("model", e.target.value)}
                    placeholder="Punto, Serie 3, Classe A..."
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="year">Anno *</Label>
                  <Input
                    id="year"
                    type="number"
                    min="1990"
                    max={new Date().getFullYear()}
                    value={vehicleData.year}
                    onChange={(e) => handleInputChange("year", e.target.value)}
                    placeholder="2020"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="color">Colore</Label>
                  <Input
                    id="color"
                    value={vehicleData.color}
                    onChange={(e) => handleInputChange("color", e.target.value)}
                    placeholder="Bianco, Nero, Rosso..."
                  />
                </div>

                <div>
                  <Label htmlFor="fuelType">Tipo Carburante</Label>
                  <Select onValueChange={(value) => handleInputChange("fuelType", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleziona carburante" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="benzina">Benzina</SelectItem>
                      <SelectItem value="diesel">Diesel</SelectItem>
                      <SelectItem value="gpl">GPL</SelectItem>
                      <SelectItem value="metano">Metano</SelectItem>
                      <SelectItem value="ibrida">Ibrida</SelectItem>
                      <SelectItem value="elettrica">Elettrica</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="engineSize">Cilindrata</Label>
                  <Input
                    id="engineSize"
                    value={vehicleData.engineSize}
                    onChange={(e) => handleInputChange("engineSize", e.target.value)}
                    placeholder="1600, 2000..."
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="vin">Numero Telaio (VIN)</Label>
                <Input
                  id="vin"
                  value={vehicleData.vin}
                  onChange={(e) => handleInputChange("vin", e.target.value.toUpperCase())}
                  placeholder="WVWZZZ1JZ3W386752"
                  className="uppercase font-mono"
                />
              </div>

              <div>
                <Label htmlFor="notes">Note Aggiuntive</Label>
                <Textarea
                  id="notes"
                  value={vehicleData.notes}
                  onChange={(e) => handleInputChange("notes", e.target.value)}
                  placeholder="Eventuali note sul veicolo..."
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          {/* Vehicle Images */}
          <Card className="bg-white">
            <CardHeader>
              <CardTitle className="text-gray-800">Foto Veicolo</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="images">Carica Foto (Max 6)</Label>
                <Input
                  id="images"
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handleImageUpload}
                  className="mt-1"
                />
                <p className="text-sm text-muted-foreground mt-1">
                  Formati supportati: JPG, PNG, GIF. Massimo 6 immagini.
                </p>
              </div>

              {vehicleData.images.length > 0 && (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {vehicleData.images.map((image, index) => (
                    <div key={index} className="relative group">
                      <img
                        src={image || "/placeholder.svg"}
                        alt={`Veicolo ${index + 1}`}
                        className="w-full h-32 object-cover rounded-lg border"
                      />
                      <Button
                        type="button"
                        variant="destructive"
                        size="sm"
                        className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => removeImage(index)}
                      >
                        ×
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Submit Button */}
          <div className="flex gap-4">
            <Link href={`/customer/${customerId}/dashboard`} className="flex-1">
              <Button type="button" variant="outline" className="w-full bg-white">
                Annulla
              </Button>
            </Link>
            <Button type="submit" disabled={isSubmitting} className="flex-1 bg-gray-600 hover:bg-gray-700">
              {isSubmitting ? "Salvando..." : "Salva Veicolo"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}
