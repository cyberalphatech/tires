"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import Link from "next/link"
import { useParams, useRouter } from "next/navigation"

interface NoteRecord {
  id: string
  date: string
  note: string
  author: string
}

interface Vehicle {
  id: string
  licensePlate: string
  make: string
  model: string
}

export default function AddNotesPage() {
  const params = useParams()
  const router = useRouter()
  const customerId = params.id as string
  const vehicleId = params.vehicleId as string

  const [vehicle, setVehicle] = useState<Vehicle | null>(null)
  const [notesHistory, setNotesHistory] = useState<NoteRecord[]>([])
  const [newNote, setNewNote] = useState("")

  useEffect(() => {
    // Load vehicle data
    const vehiclesData = localStorage.getItem(`vehicles_${customerId}`)
    if (vehiclesData) {
      const vehicles: Vehicle[] = JSON.parse(vehiclesData)
      const foundVehicle = vehicles.find((v) => v.id === vehicleId)
      setVehicle(foundVehicle || null)
    }

    // Load notes history
    const notesData = localStorage.getItem(`notes_history_${vehicleId}`)
    if (notesData) {
      setNotesHistory(JSON.parse(notesData))
    }
  }, [customerId, vehicleId])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newNote.trim()) return

    const newRecord: NoteRecord = {
      id: Date.now().toString(),
      date: new Date().toLocaleDateString("it-IT") + " " + new Date().toLocaleTimeString("it-IT"),
      note: newNote.trim(),
      author: "Operatore",
    }

    // Update notes history
    const updatedHistory = [newRecord, ...notesHistory]
    setNotesHistory(updatedHistory)
    localStorage.setItem(`notes_history_${vehicleId}`, JSON.stringify(updatedHistory))

    // Reset form
    setNewNote("")
  }

  if (!vehicle) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-4">Caricamento...</h2>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100">
      {/* Header */}
      <div className="bg-white border-b border-green-200">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href={`/customer/${customerId}/vehicle/${vehicleId}`}>
                <Button variant="outline" size="sm">
                  ← Indietro
                </Button>
              </Link>
              <div>
                <h1 className="text-xl font-bold text-green-800">Gestione Note</h1>
                <p className="text-sm text-green-600">
                  {vehicle.licensePlate} • {vehicle.make} {vehicle.model}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-4">
        {/* Add New Note */}
        <Card className="mb-8 bg-white border-green-200">
          <CardHeader>
            <CardTitle className="text-green-800">Aggiungi Nuova Nota</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="newNote" className="text-green-700">
                  Nota *
                </Label>
                <Textarea
                  id="newNote"
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                  placeholder="Inserisci la tua nota..."
                  required
                  rows={4}
                  className="border-green-200 focus:border-green-400"
                />
              </div>

              <Button type="submit" className="w-full bg-green-600 hover:bg-green-700">
                Salva Nota
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Notes History */}
        <Card className="bg-white border-green-200">
          <CardHeader>
            <CardTitle className="text-green-800">Storico Note</CardTitle>
          </CardHeader>
          <CardContent>
            {notesHistory.length === 0 ? (
              <p className="text-center text-green-600 py-8">Nessuna nota registrata</p>
            ) : (
              <div className="space-y-4">
                {notesHistory.map((record) => (
                  <div key={record.id} className="border border-green-200 rounded-lg p-4">
                    <div className="flex justify-between items-start mb-2">
                      <p className="text-sm text-green-600">{record.date}</p>
                      <p className="text-xs text-green-500">{record.author}</p>
                    </div>
                    <p className="text-green-800 bg-green-50 p-3 rounded">{record.note}</p>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
