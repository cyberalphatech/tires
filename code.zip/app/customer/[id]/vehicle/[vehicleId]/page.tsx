"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"
import { useParams } from "next/navigation"

interface Vehicle {
  id: string
  licensePlate: string
  make: string
  model: string
  year: string
  totalKm: string
  vin: string
  color: string
  fuelType: string
  images: string[]
}

interface Customer {
  firstName: string
  lastName: string
}

export default function VehicleDetails() {
  const params = useParams()
  const customerId = params.id as string
  const vehicleId = params.vehicleId as string
  const [vehicle, setVehicle] = useState<Vehicle | null>(null)
  const [customer, setCustomer] = useState<Customer | null>(null)

  useEffect(() => {
    // Load customer data
    const customerData = localStorage.getItem(`customer_${customerId}`)
    if (customerData) {
      setCustomer(JSON.parse(customerData))
    }

    // Load vehicles and find the specific vehicle
    const vehiclesData = localStorage.getItem(`vehicles_${customerId}`)
    if (vehiclesData) {
      const vehicles: Vehicle[] = JSON.parse(vehiclesData)
      const foundVehicle = vehicles.find((v) => v.id === vehicleId)
      setVehicle(foundVehicle || null)
    }
  }, [customerId, vehicleId])

  if (!vehicle || !customer) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-4">Caricamento veicolo...</h2>
          <Link href={`/customer/${customerId}/dashboard`}>
            <Button variant="outline">Torna al Dashboard</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5">
      {/* Header */}
      <div className="bg-card border-b border-border">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href={`/customer/${customerId}/dashboard`}>
                <Button variant="outline" size="sm">
                  ← Dashboard
                </Button>
              </Link>
              <div>
                <h1 className="text-xl font-bold text-primary">{vehicle.licensePlate}</h1>
                <p className="text-sm text-muted-foreground">
                  {customer.firstName} {customer.lastName} • {vehicle.make} {vehicle.model}
                </p>
              </div>
            </div>

            <div className="text-right">
              <p className="text-sm text-muted-foreground">Anno</p>
              <p className="font-semibold">{vehicle.year}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto p-4">
        {/* Vehicle Info Card */}
        <Card className="mb-8 bg-card">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-foreground mb-3">Dettagli Veicolo</h3>
                <div className="space-y-2 text-sm">
                  <p>
                    <span className="font-medium">Targa:</span> {vehicle.licensePlate}
                  </p>
                  <p>
                    <span className="font-medium">Marca:</span> {vehicle.make}
                  </p>
                  <p>
                    <span className="font-medium">Modello:</span> {vehicle.model}
                  </p>
                  <p>
                    <span className="font-medium">Anno:</span> {vehicle.year}
                  </p>
                  <p>
                    <span className="font-medium">Colore:</span> {vehicle.color}
                  </p>
                  <p>
                    <span className="font-medium">Carburante:</span> {vehicle.fuelType}
                  </p>
                </div>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-3">Informazioni Tecniche</h3>
                <div className="space-y-2 text-sm">
                  <p>
                    <span className="font-medium">VIN:</span> {vehicle.vin}
                  </p>
                  <p>
                    <span className="font-medium">Chilometraggio:</span>{" "}
                    {Number.parseInt(vehicle.totalKm).toLocaleString()} km
                  </p>
                </div>
              </div>
            </div>

            {/* Vehicle Images */}
            {vehicle.images.length > 0 && (
              <div className="mt-6">
                <h3 className="font-semibold text-foreground mb-3">Foto Veicolo</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {vehicle.images.map((image, index) => (
                    <div key={index} className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
                      <img
                        src={image || "/placeholder.svg"}
                        alt={`Foto veicolo ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="mb-8 text-center">
          <h2 className="text-2xl font-bold text-foreground mb-4">Azioni Veicolo</h2>
          <p className="text-muted-foreground">Seleziona un'azione per continuare</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
          {/* Add Total KM */}
          <Link href={`/customer/${customerId}/vehicle/${vehicleId}/update-km`}>
            <Card className="bg-gradient-to-br from-blue-50 to-blue-100 hover:from-blue-100 hover:to-blue-200 border-2 border-transparent hover:border-blue-300 transition-all duration-200 cursor-pointer group">
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center space-y-4">
                  <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
                    <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-blue-800">AGGIORNA KM</h3>
                    <p className="text-xs text-blue-700">Registra chilometraggio</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          {/* Add Notes */}
          <Link href={`/customer/${customerId}/vehicle/${vehicleId}/add-notes`}>
            <Card className="bg-gradient-to-br from-green-50 to-green-100 hover:from-green-100 hover:to-green-200 border-2 border-transparent hover:border-green-300 transition-all duration-200 cursor-pointer group">
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center space-y-4">
                  <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
                    <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-green-800">AGGIUNGI NOTE</h3>
                    <p className="text-xs text-green-700">Annotazioni veicolo</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          {/* Change New Tire */}
          <Link href={`/customer/${customerId}/vehicle/${vehicleId}/new-tires`}>
            <Card className="bg-gradient-to-br from-orange-50 to-orange-100 hover:from-orange-100 hover:to-orange-200 border-2 border-transparent hover:border-orange-300 transition-all duration-200 cursor-pointer group">
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center space-y-4">
                  <div className="w-16 h-16 bg-orange-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
                    <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                      <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" fill="none" />
                      <circle cx="12" cy="12" r="6" stroke="currentColor" strokeWidth="2" fill="none" />
                      <circle cx="12" cy="12" r="2" fill="currentColor" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-orange-800">GOMME NUOVE</h3>
                    <p className="text-xs text-orange-700">Installa pneumatici</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          {/* Season Change */}
          <Link href={`/customer/${customerId}/vehicle/${vehicleId}/season-change`}>
            <Card className="bg-gradient-to-br from-purple-50 to-purple-100 hover:from-purple-100 hover:to-purple-200 border-2 border-transparent hover:border-purple-300 transition-all duration-200 cursor-pointer group">
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center space-y-4">
                  <div className="w-16 h-16 bg-purple-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
                    <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-purple-800">CAMBIO STAGIONE</h3>
                    <p className="text-xs text-purple-700">Inverno/Estate</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          {/* Tire Cards Management */}
          <Link href={`/customer/${customerId}/vehicle/${vehicleId}/tire-cards`}>
            <Card className="bg-gradient-to-br from-cyan-50 to-cyan-100 hover:from-cyan-100 hover:to-cyan-200 border-2 border-transparent hover:border-cyan-300 transition-all duration-200 cursor-pointer group max-w-xs">
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center space-y-4">
                  <div className="w-16 h-16 bg-cyan-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
                    <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M19 3H5C3.9 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V5C21 3.9 20.1 3 19 3ZM19 19H5V5H19V19ZM17 12H15V17H17V12ZM13 7H11V17H13V7ZM9 10H7V17H9V10Z" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-cyan-800">GESTIONE PNEUMATICI</h3>
                    <p className="text-xs text-cyan-700">Vista a schede con azioni</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        </div>

        {/* Quick Stats for this vehicle */}
        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-card">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">0</div>
              <div className="text-sm text-muted-foreground">Set Invernali</div>
            </CardContent>
          </Card>

          <Card className="bg-card">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-orange-600">0</div>
              <div className="text-sm text-muted-foreground">Set Estivi</div>
            </CardContent>
          </Card>

          <Card className="bg-card">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">0</div>
              <div className="text-sm text-muted-foreground">Cambi Effettuati</div>
            </CardContent>
          </Card>

          <Card className="bg-card">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">0</div>
              <div className="text-sm text-muted-foreground">Note Salvate</div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
