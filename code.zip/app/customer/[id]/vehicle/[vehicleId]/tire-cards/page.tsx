"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import Link from "next/link"
import { useParams } from "next/navigation"

interface Vehicle {
  id: string
  licensePlate: string
  make: string
  model: string
  year: string
}

interface Customer {
  firstName: string
  lastName: string
}

interface TireCard {
  id: string
  vehicleId: string
  position: string
  brand: string
  size: string
  tireCode: string
  dotCode: string
  year: string
  treadDepth: string
  condition: "ottimo" | "buono" | "discreto" | "usurato"
  season: "winter" | "summer"
  status: "montato" | "depositato" | "smaltito"
  warehouseLocation: string
  notes: string
  lastUpdate: string
}

export default function TireCardsPage() {
  const params = useParams()
  const customerId = params.id as string
  const vehicleId = params.vehicleId as string

  const [customer, setCustomer] = useState<Customer | null>(null)
  const [vehicle, setVehicle] = useState<Vehicle | null>(null)
  const [tires, setTires] = useState<TireCard[]>([])
  const [selectedTire, setSelectedTire] = useState<TireCard | null>(null)
  const [showLocationModal, setShowLocationModal] = useState(false)
  const [newLocation, setNewLocation] = useState("")
  const [selectedTires, setSelectedTires] = useState<Set<string>>(new Set())

  useEffect(() => {
    const customerData = localStorage.getItem(`customer_${customerId}`)
    if (customerData) {
      setCustomer(JSON.parse(customerData))
    }

    const vehiclesData = localStorage.getItem(`vehicles_${customerId}`)
    if (vehiclesData) {
      const vehicles: Vehicle[] = JSON.parse(vehiclesData)
      const foundVehicle = vehicles.find((v) => v.id === vehicleId)
      setVehicle(foundVehicle || null)
    }

    const tiresData = localStorage.getItem(`vehicle_tires_${vehicleId}`)
    if (tiresData) {
      setTires(JSON.parse(tiresData))
    } else {
      const sampleTires: TireCard[] = [
        {
          id: "1",
          vehicleId,
          position: "A6 (Anteriore Sinistro)",
          brand: "Michelin",
          size: "205/55R16",
          tireCode: "FF925AB",
          dotCode: "DOT",
          year: "2024",
          treadDepth: "7.0",
          condition: "buono",
          season: "summer",
          status: "montato",
          warehouseLocation: "Scaffale B-12",
          notes: "Pneumatico in buone condizioni",
          lastUpdate: new Date().toISOString(),
        },
        {
          id: "2",
          vehicleId,
          position: "A5 (Anteriore Destro)",
          brand: "Continental",
          size: "205/55R16",
          tireCode: "CT456XY",
          dotCode: "DOT",
          year: "2024",
          treadDepth: "6.5",
          condition: "buono",
          season: "summer",
          status: "montato",
          warehouseLocation: "Scaffale B-13",
          notes: "",
          lastUpdate: new Date().toISOString(),
        },
        {
          id: "3",
          vehicleId,
          position: "P6 (Posteriore Sinistro)",
          brand: "Pirelli",
          size: "205/55R16",
          tireCode: "PR789ZW",
          dotCode: "DOT",
          year: "2023",
          treadDepth: "5.5",
          condition: "discreto",
          season: "summer",
          status: "depositato",
          warehouseLocation: "Scaffale B-14",
          notes: "Da controllare usura",
          lastUpdate: new Date().toISOString(),
        },
        {
          id: "4",
          vehicleId,
          position: "P4 (Posteriore Destro)",
          brand: "Bridgestone",
          size: "205/55R16",
          tireCode: "BR123QW",
          dotCode: "DOT",
          year: "2023",
          treadDepth: "5.0",
          condition: "discreto",
          season: "summer",
          status: "depositato",
          warehouseLocation: "Scaffale B-15",
          notes: "",
          lastUpdate: new Date().toISOString(),
        },
      ]
      setTires(sampleTires)
      localStorage.setItem(`vehicle_tires_${vehicleId}`, JSON.stringify(sampleTires))
    }
  }, [customerId, vehicleId])

  const updateTireStatus = (tireId: string, newStatus: TireCard["status"]) => {
    const updatedTires = tires.map((tire) =>
      tire.id === tireId ? { ...tire, status: newStatus, lastUpdate: new Date().toISOString() } : tire,
    )
    setTires(updatedTires)
    localStorage.setItem(`vehicle_tires_${vehicleId}`, JSON.stringify(updatedTires))
  }

  const updateTireLocation = (tireId: string, location: string) => {
    const updatedTires = tires.map((tire) =>
      tire.id === tireId ? { ...tire, warehouseLocation: location, lastUpdate: new Date().toISOString() } : tire,
    )
    setTires(updatedTires)
    localStorage.setItem(`vehicle_tires_${vehicleId}`, JSON.stringify(updatedTires))
    setShowLocationModal(false)
    setSelectedTire(null)
    setNewLocation("")
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "montato":
        return "bg-green-100 text-green-800 border-green-300"
      case "depositato":
        return "bg-blue-100 text-blue-800 border-blue-300"
      case "smaltito":
        return "bg-red-100 text-red-800 border-red-300"
      default:
        return "bg-gray-100 text-gray-800 border-gray-300"
    }
  }

  const getConditionColor = (condition: string) => {
    switch (condition) {
      case "ottimo":
        return "bg-green-500"
      case "buono":
        return "bg-blue-500"
      case "discreto":
        return "bg-orange-500"
      case "usurato":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  const handleTireSelection = (tireId: string, checked: boolean) => {
    const newSelected = new Set(selectedTires)
    if (checked) {
      newSelected.add(tireId)
    } else {
      newSelected.delete(tireId)
    }
    setSelectedTires(newSelected)
  }

  const handleBulkAction = (action: string) => {
    const selectedTireIds = Array.from(selectedTires)
    if (selectedTireIds.length === 0) return

    let newStatus: TireCard["status"]
    switch (action) {
      case "install":
        newStatus = "montato"
        break
      case "remove":
        newStatus = "depositato"
        break
      case "dispose":
        newStatus = "smaltito"
        break
      case "remove_store":
        newStatus = "depositato"
        break
      default:
        return
    }

    const updatedTires = tires.map((tire) =>
      selectedTireIds.includes(tire.id) ? { ...tire, status: newStatus, lastUpdate: new Date().toISOString() } : tire,
    )
    setTires(updatedTires)
    localStorage.setItem(`vehicle_tires_${vehicleId}`, JSON.stringify(updatedTires))
    setSelectedTires(new Set())
  }

  const mountedTires = tires.filter((tire) => tire.status === "montato")
  const storedTires = tires.filter((tire) => tire.status === "depositato")
  const disposedTires = tires.filter((tire) => tire.status === "smaltito")

  if (!customer || !vehicle) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-4">Caricamento...</h2>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100">
      {/* Header */}
      <div className="bg-white border-b border-green-200">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href={`/customer/${customerId}/vehicle/${vehicleId}`}>
                <Button variant="outline" size="sm">
                  ← Dettagli Veicolo
                </Button>
              </Link>
              <div>
                <h1 className="text-xl font-bold text-green-800">Gestione Pneumatici</h1>
                <p className="text-sm text-green-600">
                  {vehicle.licensePlate} • {vehicle.make} {vehicle.model} • {customer.firstName} {customer.lastName}
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-green-600">Selezionati</p>
              <p className="text-2xl font-bold text-green-800">{selectedTires.size}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {/* Bulk Action Buttons */}
        {selectedTires.size > 0 && (
          <div className="mb-6 flex gap-3 justify-center">
            <Button
              onClick={() => handleBulkAction("install")}
              className="px-6 py-3 bg-white text-black border-2 border-black hover:bg-gray-50 font-semibold"
            >
              INSTALLARE
            </Button>
            <Button
              onClick={() => handleBulkAction("remove")}
              className="px-6 py-3 bg-white text-black border-2 border-black hover:bg-gray-50 font-semibold"
            >
              SMONTARE
            </Button>
            <Button
              onClick={() => handleBulkAction("dispose")}
              className="px-6 py-3 bg-white text-red-600 border-2 border-red-600 hover:bg-red-50 font-semibold"
            >
              SMALTIRE
            </Button>
            <Button
              onClick={() => handleBulkAction("remove_store")}
              className="px-6 py-3 bg-white text-black border-2 border-black hover:bg-gray-50 font-semibold"
            >
              SMONTARE + DEPOSITO
            </Button>
          </div>
        )}

        {/* Pneumatici Montati */}
        {mountedTires.length > 0 && (
          <div className="mb-8">
            <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" fill="none" />
                <circle cx="12" cy="12" r="6" stroke="currentColor" strokeWidth="2" fill="none" />
                <circle cx="12" cy="12" r="2" fill="currentColor" />
              </svg>
              Pneumatici Montati ({mountedTires.length})
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {mountedTires.map((tire) => (
                <Card
                  key={tire.id}
                  className="bg-green-50 border-2 border-green-200 hover:shadow-lg transition-all duration-200 relative"
                >
                  <CardContent className="p-6">
                    <div className="absolute top-4 right-4">
                      <Checkbox
                        checked={selectedTires.has(tire.id)}
                        onCheckedChange={(checked) => handleTireSelection(tire.id, checked as boolean)}
                        className="w-5 h-5"
                      />
                    </div>

                    <div className="mb-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className="bg-green-100 text-green-800 border-green-300">storage</Badge>
                        <Badge className="bg-orange-100 text-orange-800 border-orange-300">{tire.season}</Badge>
                      </div>
                      <h3 className="text-lg font-bold text-gray-800">{tire.brand}</h3>
                      <p className="text-gray-600">{tire.size}</p>
                    </div>

                    <div className="space-y-2 text-sm text-gray-600">
                      <p>
                        <span className="font-medium">Posizione:</span> {tire.position}
                      </p>
                      <p>
                        <span className="font-medium">Battistrada:</span> {tire.treadDepth}mm
                      </p>
                      <p>
                        <span className="font-medium">Condizione:</span> {tire.condition}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Pneumatici in Deposito */}
        {storedTires.length > 0 && (
          <div className="mb-8">
            <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2L2 7V17C2 18.1 2.9 19 4 19H20C21.1 19 22 18.1 22 17V7L12 2ZM20 17H4V8.27L12 4.14L20 8.27V17Z" />
              </svg>
              Pneumatici in Deposito ({storedTires.length})
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {storedTires.map((tire) => (
                <Card
                  key={tire.id}
                  className="bg-green-50 border-2 border-green-200 hover:shadow-lg transition-all duration-200 relative"
                >
                  <CardContent className="p-6">
                    <div className="absolute top-4 right-4">
                      <Checkbox
                        checked={selectedTires.has(tire.id)}
                        onCheckedChange={(checked) => handleTireSelection(tire.id, checked as boolean)}
                        className="w-5 h-5"
                      />
                    </div>

                    <div className="mb-4">
                      <h3 className="text-lg font-bold text-gray-800">{tire.brand}</h3>
                      <p className="text-gray-600">{tire.size}</p>
                      <Badge className="bg-orange-100 text-orange-800 border-orange-300 mt-2">{tire.season}</Badge>
                    </div>

                    <div className="space-y-2 text-sm text-gray-600">
                      <p>
                        <span className="font-medium">Posizione:</span> {tire.position}
                      </p>
                      <p>
                        <span className="font-medium">Battistrada:</span> {tire.treadDepth}mm
                      </p>
                      <p>
                        <span className="font-medium">Condizione:</span> {tire.condition}
                      </p>
                      <div className="flex items-center gap-1 text-xs">
                        <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
                        </svg>
                        {tire.warehouseLocation}
                      </div>
                      <div className="flex items-center gap-1 text-xs">
                        <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M9 11H7v6h2v-6zm4 0h-2v6h2v-6zm4 0h-2v6h2v-6zm2-7h-3V2h-2v2H8V2H6v2H3c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 16H3V8h14v12z" />
                        </svg>
                        {new Date(tire.lastUpdate).toLocaleDateString("it-IT")}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Pneumatici Consegnati */}
        {disposedTires.length > 0 && (
          <div className="mb-8">
            <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                <path d="M16 6V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H8v2h14V6h-3zM8 6V4h8v2H8zm2 12h4v2H10v-2zm-4-2h12l-1-10H7l-1 10z" />
              </svg>
              Pneumatici Consegnati ({disposedTires.length})
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {disposedTires.map((tire) => (
                <Card
                  key={tire.id}
                  className="bg-gray-50 border-2 border-gray-200 hover:shadow-lg transition-all duration-200 relative opacity-75"
                >
                  <CardContent className="p-6">
                    <div className="absolute top-4 right-4">
                      <Checkbox
                        checked={selectedTires.has(tire.id)}
                        onCheckedChange={(checked) => handleTireSelection(tire.id, checked as boolean)}
                        className="w-5 h-5"
                      />
                    </div>

                    <div className="mb-4">
                      <h3 className="text-lg font-bold text-gray-600">{tire.brand}</h3>
                      <p className="text-gray-500">{tire.size}</p>
                      <Badge className="bg-red-100 text-red-800 border-red-300 mt-2">smaltito</Badge>
                    </div>

                    <div className="space-y-2 text-sm text-gray-500">
                      <p>
                        <span className="font-medium">Posizione:</span> {tire.position}
                      </p>
                      <p>
                        <span className="font-medium">Battistrada:</span> {tire.treadDepth}mm
                      </p>
                      <p>
                        <span className="font-medium">Condizione:</span> {tire.condition}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Location Update Modal */}
        {showLocationModal && selectedTire && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <Card className="w-full max-w-md mx-4">
              <CardHeader>
                <CardTitle className="text-green-800">Aggiorna Posizione Magazzino</CardTitle>
                <p className="text-sm text-muted-foreground">
                  {selectedTire.position} • {selectedTire.tireCode}
                </p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="location">Nuova Posizione</Label>
                  <Select value={newLocation} onValueChange={setNewLocation}>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleziona posizione" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Scaffale A-01">Scaffale A-01</SelectItem>
                      <SelectItem value="Scaffale A-02">Scaffale A-02</SelectItem>
                      <SelectItem value="Scaffale A-03">Scaffale A-03</SelectItem>
                      <SelectItem value="Scaffale B-01">Scaffale B-01</SelectItem>
                      <SelectItem value="Scaffale B-02">Scaffale B-02</SelectItem>
                      <SelectItem value="Scaffale B-03">Scaffale B-03</SelectItem>
                      <SelectItem value="Area Smaltimento">Area Smaltimento</SelectItem>
                      <SelectItem value="In Lavorazione">In Lavorazione</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setShowLocationModal(false)
                      setSelectedTire(null)
                      setNewLocation("")
                    }}
                    className="flex-1"
                  >
                    Annulla
                  </Button>
                  <Button
                    onClick={() => updateTireLocation(selectedTire.id, newLocation)}
                    className="flex-1 bg-green-600 hover:bg-green-700"
                  >
                    Salva
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
