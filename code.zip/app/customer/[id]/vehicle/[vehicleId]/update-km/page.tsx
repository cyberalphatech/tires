"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import Link from "next/link"
import { useParams, useRouter } from "next/navigation"

interface KmRecord {
  id: string
  date: string
  km: string
  previousKm: string
  difference: string
  notes?: string
}

interface Vehicle {
  id: string
  licensePlate: string
  make: string
  model: string
  totalKm: string
}

export default function UpdateKmPage() {
  const params = useParams()
  const router = useRouter()
  const customerId = params.id as string
  const vehicleId = params.vehicleId as string

  const [vehicle, setVehicle] = useState<Vehicle | null>(null)
  const [kmHistory, setKmHistory] = useState<KmRecord[]>([])
  const [newKm, setNewKm] = useState("")
  const [notes, setNotes] = useState("")

  useEffect(() => {
    // Load vehicle data
    const vehiclesData = localStorage.getItem(`vehicles_${customerId}`)
    if (vehiclesData) {
      const vehicles: Vehicle[] = JSON.parse(vehiclesData)
      const foundVehicle = vehicles.find((v) => v.id === vehicleId)
      setVehicle(foundVehicle || null)
    }

    // Load KM history
    const historyData = localStorage.getItem(`km_history_${vehicleId}`)
    if (historyData) {
      setKmHistory(JSON.parse(historyData))
    }
  }, [customerId, vehicleId])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!vehicle || !newKm) return

    const newRecord: KmRecord = {
      id: Date.now().toString(),
      date: new Date().toLocaleDateString("it-IT"),
      km: newKm,
      previousKm: vehicle.totalKm,
      difference: (Number.parseInt(newKm) - Number.parseInt(vehicle.totalKm)).toString(),
      notes: notes || undefined,
    }

    // Update KM history
    const updatedHistory = [newRecord, ...kmHistory]
    setKmHistory(updatedHistory)
    localStorage.setItem(`km_history_${vehicleId}`, JSON.stringify(updatedHistory))

    // Update vehicle's total KM
    const vehiclesData = localStorage.getItem(`vehicles_${customerId}`)
    if (vehiclesData) {
      const vehicles: Vehicle[] = JSON.parse(vehiclesData)
      const updatedVehicles = vehicles.map((v) => (v.id === vehicleId ? { ...v, totalKm: newKm } : v))
      localStorage.setItem(`vehicles_${customerId}`, JSON.stringify(updatedVehicles))
    }

    // Reset form and redirect
    setNewKm("")
    setNotes("")
    router.push(`/customer/${customerId}/vehicle/${vehicleId}`)
  }

  if (!vehicle) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-4">Caricamento...</h2>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100">
      {/* Header */}
      <div className="bg-white border-b border-blue-200">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href={`/customer/${customerId}/vehicle/${vehicleId}`}>
                <Button variant="outline" size="sm">
                  ← Indietro
                </Button>
              </Link>
              <div>
                <h1 className="text-xl font-bold text-blue-800">Aggiorna Chilometraggio</h1>
                <p className="text-sm text-blue-600">
                  {vehicle.licensePlate} • {vehicle.make} {vehicle.model}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-4">
        {/* Current KM Display */}
        <Card className="mb-6 bg-white border-blue-200">
          <CardContent className="p-6">
            <div className="text-center">
              <p className="text-sm text-blue-600 mb-2">Chilometraggio Attuale</p>
              <p className="text-3xl font-bold text-blue-800">{Number.parseInt(vehicle.totalKm).toLocaleString()} km</p>
            </div>
          </CardContent>
        </Card>

        {/* Update Form */}
        <Card className="mb-8 bg-white border-blue-200">
          <CardHeader>
            <CardTitle className="text-blue-800">Nuovo Chilometraggio</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="newKm" className="text-blue-700">
                  Chilometraggio *
                </Label>
                <Input
                  id="newKm"
                  type="number"
                  value={newKm}
                  onChange={(e) => setNewKm(e.target.value)}
                  placeholder="Inserisci nuovo chilometraggio"
                  required
                  className="border-blue-200 focus:border-blue-400"
                />
              </div>

              <div>
                <Label htmlFor="notes" className="text-blue-700">
                  Note (opzionale)
                </Label>
                <Input
                  id="notes"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Aggiungi note..."
                  className="border-blue-200 focus:border-blue-400"
                />
              </div>

              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                Aggiorna Chilometraggio
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* KM History */}
        <Card className="bg-white border-blue-200">
          <CardHeader>
            <CardTitle className="text-blue-800">Storico Chilometraggio</CardTitle>
          </CardHeader>
          <CardContent>
            {kmHistory.length === 0 ? (
              <p className="text-center text-blue-600 py-8">Nessun aggiornamento registrato</p>
            ) : (
              <div className="space-y-4">
                {kmHistory.map((record) => (
                  <div key={record.id} className="border border-blue-200 rounded-lg p-4">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <p className="font-semibold text-blue-800">{Number.parseInt(record.km).toLocaleString()} km</p>
                        <p className="text-sm text-blue-600">{record.date}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-blue-600">
                          +{Number.parseInt(record.difference).toLocaleString()} km
                        </p>
                        <p className="text-xs text-blue-500">
                          Da: {Number.parseInt(record.previousKm).toLocaleString()} km
                        </p>
                      </div>
                    </div>
                    {record.notes && <p className="text-sm text-blue-700 bg-blue-50 p-2 rounded">{record.notes}</p>}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
