"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import Link from "next/link"
import { useParams, useRouter } from "next/navigation"

interface TirePosition {
  id: string
  position: string
  brand: string
  model: string
  size: string
  dotCode: string
  year: string
  treadDepth: string
  condition: string
  price: string
  isRemovable: boolean
}

interface Vehicle {
  id: string
  licensePlate: string
  make: string
  model: string
}

export default function NewTiresPage() {
  const params = useParams()
  const router = useRouter()
  const customerId = params.id as string
  const vehicleId = params.vehicleId as string

  const [vehicle, setVehicle] = useState<Vehicle | null>(null)
  const [tires, setTires] = useState<TirePosition[]>([
    {
      id: "1",
      position: "anteriore_sinistro",
      brand: "",
      model: "",
      size: "",
      dotCode: "",
      year: "",
      treadDepth: "",
      condition: "Nuovo",
      price: "",
      isRemovable: false,
    },
    {
      id: "2",
      position: "anteriore_destro",
      brand: "",
      model: "",
      size: "",
      dotCode: "",
      year: "",
      treadDepth: "",
      condition: "Nuovo",
      price: "",
      isRemovable: false,
    },
    {
      id: "3",
      position: "posteriore_sinistro",
      brand: "",
      model: "",
      size: "",
      dotCode: "",
      year: "",
      treadDepth: "",
      condition: "Nuovo",
      price: "",
      isRemovable: false,
    },
    {
      id: "4",
      position: "posteriore_destro",
      brand: "",
      model: "",
      size: "",
      dotCode: "",
      year: "",
      treadDepth: "",
      condition: "Nuovo",
      price: "",
      isRemovable: false,
    },
  ])

  useEffect(() => {
    // Load vehicle data
    const vehiclesData = localStorage.getItem(`vehicles_${customerId}`)
    if (vehiclesData) {
      const vehicles: Vehicle[] = JSON.parse(vehiclesData)
      const foundVehicle = vehicles.find((v) => v.id === vehicleId)
      setVehicle(foundVehicle || null)
    }
  }, [customerId, vehicleId])

  const addSpareTire = () => {
    const newTire: TirePosition = {
      id: Date.now().toString(),
      position: "scorta",
      brand: "",
      model: "",
      size: "",
      dotCode: "",
      year: "",
      treadDepth: "",
      condition: "Nuovo",
      price: "",
      isRemovable: true,
    }
    setTires([...tires, newTire])
  }

  const removeTire = (tireId: string) => {
    setTires(tires.filter((tire) => tire.id !== tireId))
  }

  const updateTire = (tireId: string, field: keyof TirePosition, value: string) => {
    const updatedTires = tires.map((tire) => (tire.id === tireId ? { ...tire, [field]: value } : tire))
    setTires(updatedTires)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Save tire installation record
    const installationRecord = {
      id: Date.now().toString(),
      vehicleId,
      customerId,
      date: new Date().toLocaleDateString("it-IT"),
      tires: tires.filter((tire) => tire.brand && tire.model),
      totalPrice: tires.reduce((sum, tire) => sum + (Number.parseFloat(tire.price) || 0), 0).toString(),
    }

    // Save to localStorage
    const existingInstallations = localStorage.getItem(`tire_installations_${vehicleId}`) || "[]"
    const installations = JSON.parse(existingInstallations)
    installations.unshift(installationRecord)
    localStorage.setItem(`tire_installations_${vehicleId}`, JSON.stringify(installations))

    router.push(`/customer/${customerId}/vehicle/${vehicleId}`)
  }

  const getPositionDisplayName = (position: string) => {
    switch (position) {
      case "anteriore_destro":
        return "Anteriore Destro"
      case "anteriore_sinistro":
        return "Anteriore Sinistro"
      case "posteriore_destro":
        return "Posteriore Destro"
      case "posteriore_sinistro":
        return "Posteriore Sinistro"
      case "scorta":
        return "Scorta"
      default:
        return position
    }
  }

  if (!vehicle) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-4">Caricamento...</h2>
        </div>
      </div>
    )
  }

  const totalPrice = tires.reduce((sum, tire) => sum + (Number.parseFloat(tire.price) || 0), 0)

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href={`/customer/${customerId}/vehicle/${vehicleId}`}>
                <Button variant="outline" size="sm">
                  ← Indietro
                </Button>
              </Link>
              <div>
                <h1 className="text-xl font-bold text-gray-800">Installazione Gomme Nuove</h1>
                <p className="text-sm text-gray-600">
                  {vehicle.licensePlate} • {vehicle.make} {vehicle.model}
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">Totale</p>
              <p className="text-xl font-bold text-gray-800">€{totalPrice.toFixed(2)}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-4">
        <form onSubmit={handleSubmit}>
          <div className="mb-6 text-center">
            <Button
              type="button"
              onClick={addSpareTire}
              variant="outline"
              className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
            >
              + Aggiungi Scorta
            </Button>
          </div>

          {/* Tire Positions Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {tires.map((tire) => (
              <Card key={tire.id} className="bg-white border-gray-200">
                <CardHeader className="pb-4">
                  <CardTitle className="text-gray-800 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center">
                        <svg className="w-6 h-6 text-gray-600" fill="currentColor" viewBox="0 0 24 24">
                          <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" fill="none" />
                          <circle cx="12" cy="12" r="6" stroke="currentColor" strokeWidth="2" fill="none" />
                          <circle cx="12" cy="12" r="2" fill="currentColor" />
                        </svg>
                      </div>
                      {getPositionDisplayName(tire.position)}
                    </div>
                    {tire.isRemovable && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => removeTire(tire.id)}
                        className="text-red-500 hover:text-red-700 hover:bg-red-50"
                      >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                          />
                        </svg>
                      </Button>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-gray-700">Marca</Label>
                      <Input
                        value={tire.brand}
                        onChange={(e) => updateTire(tire.id, "brand", e.target.value)}
                        placeholder="es. Michelin"
                        className="border-gray-200 focus:border-gray-400"
                      />
                    </div>
                    <div>
                      <Label className="text-gray-700">Modello</Label>
                      <Input
                        value={tire.model}
                        onChange={(e) => updateTire(tire.id, "model", e.target.value)}
                        placeholder="es. Pilot Sport"
                        className="border-gray-200 focus:border-gray-400"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-gray-700">Misura</Label>
                      <Input
                        value={tire.size}
                        onChange={(e) => updateTire(tire.id, "size", e.target.value)}
                        placeholder="es. 225/45R17"
                        className="border-gray-200 focus:border-gray-400"
                      />
                    </div>
                    <div>
                      <Label className="text-gray-700">DOT</Label>
                      <Input
                        value={tire.dotCode}
                        onChange={(e) => updateTire(tire.id, "dotCode", e.target.value)}
                        placeholder="es. 2024"
                        className="border-gray-200 focus:border-gray-400"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <Label className="text-gray-700">Anno</Label>
                      <Input
                        value={tire.year}
                        onChange={(e) => updateTire(tire.id, "year", e.target.value)}
                        placeholder="2024"
                        className="border-gray-200 focus:border-gray-400"
                      />
                    </div>
                    <div>
                      <Label className="text-gray-700">Battistrada</Label>
                      <Input
                        value={tire.treadDepth}
                        onChange={(e) => updateTire(tire.id, "treadDepth", e.target.value)}
                        placeholder="8.0"
                        className="border-gray-200 focus:border-gray-400"
                      />
                    </div>
                    <div>
                      <Label className="text-gray-700">Prezzo €</Label>
                      <Input
                        type="number"
                        step="0.01"
                        value={tire.price}
                        onChange={(e) => updateTire(tire.id, "price", e.target.value)}
                        placeholder="120.00"
                        className="border-gray-200 focus:border-gray-400"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Submit Button */}
          <div className="text-center">
            <Button type="submit" size="lg" className="bg-gray-600 hover:bg-gray-700 px-8">
              Completa Installazione - €{totalPrice.toFixed(2)}
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}
