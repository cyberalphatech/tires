"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"
import { useParams } from "next/navigation"

interface Customer {
  id: number
  first_name: string
  last_name: string
  email: string
  phone: string
  address: string
  city: string
  postal_code: string
  tax_code: string
  company_name?: string
  vat_number?: string
}

interface Vehicle {
  id: number
  license_plate: string
  make: string
  model: string
  year: number
  current_km: number
  vin?: string
  fuel_type?: string
  engine_type?: string
}

export default function CustomerDashboard() {
  const params = useParams()
  const customerId = params.id as string
  const [customer, setCustomer] = useState<Customer | null>(null)
  const [vehicles, setVehicles] = useState<Vehicle[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchCustomerData = async () => {
      try {
        const customerResponse = await fetch(`/api/customers/${customerId}`)
        if (customerResponse.ok) {
          const customerData = await customerResponse.json()
          setCustomer(customerData)
        } else {
          setError("Cliente non trovato")
        }

        const vehiclesResponse = await fetch(`/api/customers/${customerId}/vehicles`)
        if (vehiclesResponse.ok) {
          const vehiclesData = await vehiclesResponse.json()
          setVehicles(vehiclesData)
        }
      } catch (err) {
        setError("Errore nel caricamento dei dati")
        console.error("Error fetching customer data:", err)
      } finally {
        setLoading(false)
      }
    }

    fetchCustomerData()
  }, [customerId])

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-4">Caricamento cliente...</h2>
          <Link href="/customer-login">
            <Button variant="outline" className="bg-gray-100 hover:bg-gray-200 text-gray-800">
              Torna al Login
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  if (error || !customer) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-4 text-red-600">{error || "Cliente non trovato"}</h2>
          <Link href="/customer-login">
            <Button variant="outline" className="bg-gray-100 hover:bg-gray-200 text-gray-800">
              Torna al Login
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href="/customer-login">
                <Button variant="outline" size="sm" className="bg-gray-100 hover:bg-gray-200 text-gray-800">
                  ← Indietro
                </Button>
              </Link>
              <div>
                <h1 className="text-xl font-bold text-gray-900">
                  {customer.first_name} {customer.last_name}
                </h1>
                <p className="text-sm text-gray-600">Dashboard Cliente</p>
              </div>
            </div>

            <div className="text-right">
              <p className="text-sm text-gray-600">ID Cliente</p>
              <p className="font-mono text-sm">{customerId}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto p-4">
        {/* Customer Info Card */}
        <Card className="mb-8 bg-white border border-gray-200">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Informazioni Contatto</h3>
                <div className="space-y-2 text-sm">
                  <p>
                    <span className="font-medium">Email:</span> {customer.email}
                  </p>
                  <p>
                    <span className="font-medium">Telefono:</span> {customer.phone}
                  </p>
                  <p>
                    <span className="font-medium">Indirizzo:</span> {customer.address}, {customer.city}{" "}
                    {customer.postal_code}
                  </p>
                </div>
              </div>

              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Dati Fiscali</h3>
                <div className="space-y-2 text-sm">
                  {customer.tax_code && (
                    <p>
                      <span className="font-medium">Codice Fiscale:</span> {customer.tax_code}
                    </p>
                  )}
                  {customer.company_name && (
                    <p>
                      <span className="font-medium">Azienda:</span> {customer.company_name}
                    </p>
                  )}
                  {customer.vat_number && (
                    <p>
                      <span className="font-medium">P.IVA:</span> {customer.vat_number}
                    </p>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Vehicles Section */}
        {vehicles.length > 0 && (
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4 text-center">I Tuoi Veicoli</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {vehicles.map((vehicle) => (
                <Link key={vehicle.id} href={`/customer/${customerId}/vehicle/${vehicle.id}`}>
                  <Card className="bg-gradient-to-br from-blue-50 to-blue-100 hover:from-blue-100 hover:to-blue-200 border-2 border-transparent hover:border-blue-300 transition-all duration-200 cursor-pointer group">
                    <CardContent className="p-4">
                      <div className="flex flex-col items-center text-center space-y-3">
                        <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
                          <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5H15V4C15 2.9 14.1 2 13 2H11C9.9 2 9 2.9 9 4V5H6.5C5.84 5 5.28 5.42 5.08 6.01L3 12V20C3 20.55 3.45 21 4 21H5C5.55 21 6 20.55 6 20V19H18V20C18 20.55 18.45 21 19 21H20C20.55 21 21 20.55 21 20V12L18.92 6.01ZM11 4H13V5H11V4ZM6.5 16C5.67 16 5 15.33 5 14.5S5.67 13 6.5 13 8 13.67 8 14.5 7.33 16 6.5 16ZM17.5 16C16.67 16 16 15.33 16 14.5S16.67 13 17.5 13 19 13.67 19 14.5 18.33 16 17.5 16ZM5 11L6.5 7H17.5L19 11H5Z" />
                          </svg>
                        </div>

                        <div className="space-y-1">
                          <div className="bg-white px-3 py-1 rounded-lg border-2 border-blue-600">
                            <span className="font-bold text-blue-800 text-sm">{vehicle.license_plate}</span>
                          </div>
                          <p className="text-xs text-blue-700 font-medium">
                            {vehicle.make} {vehicle.model}
                          </p>
                          <p className="text-xs text-blue-600">
                            {vehicle.year} • {vehicle.current_km.toLocaleString()} km
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* Main Actions */}
        <div className="mb-8 text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Gestione Cliente</h2>
          <p className="text-gray-600">Seleziona un'azione per continuare</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-3xl mx-auto">
          {/* Add Cars */}
          <Link href={`/customer/${customerId}/add-cars`}>
            <Card className="bg-gradient-to-br from-green-50 to-green-100 hover:from-green-100 hover:to-green-200 border-2 border-transparent hover:border-green-300 transition-all duration-200 cursor-pointer group">
              <CardContent className="p-8">
                <div className="flex flex-col items-center text-center space-y-6">
                  <div className="w-20 h-20 bg-green-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
                    <svg className="w-10 h-10 text-white" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5H15V4C15 2.9 14.1 2 13 2H11C9.9 2 9 2.9 9 4V5H6.5C5.84 5 5.28 5.42 5.08 6.01L3 12V20C3 20.55 3.45 21 4 21H5C5.55 21 6 20.55 6 20V19H18V20C18 20.55 18.45 21 19 21H20C20.55 21 21 20.55 21 20V12L18.92 6.01ZM11 4H13V5H11V4ZM6.5 16C5.67 16 5 15.33 5 14.5S5.67 13 6.5 13 8 13.67 8 14.5 7.33 16 6.5 16ZM17.5 16C16.67 16 16 15.33 16 14.5S16.67 13 17.5 13 19 13.67 19 14.5 18.33 16 17.5 16ZM5 11L6.5 7H17.5L19 11H5Z" />
                      <circle cx="19" cy="8" r="3" fill="white" />
                      <path d="M19 6v4M17 8h4" stroke="currentColor" strokeWidth="1.5" />
                    </svg>
                  </div>

                  <div className="space-y-3">
                    <h3 className="text-2xl font-bold text-green-800">AGGIUNGI AUTO</h3>
                    <p className="text-green-700">Registra i veicoli del cliente per la gestione pneumatici</p>
                  </div>

                  <Button className="w-full h-12 text-lg font-semibold bg-green-600 hover:bg-green-700 text-white">
                    Gestisci Veicoli
                  </Button>
                </div>
              </CardContent>
            </Card>
          </Link>

          {/* Storage Tires */}
          <Link href={`/customer/${customerId}/storage-tires`}>
            <Card className="bg-gradient-to-br from-orange-50 to-orange-100 hover:from-orange-100 hover:to-orange-200 border-2 border-transparent hover:border-orange-300 transition-all duration-200 cursor-pointer group">
              <CardContent className="p-8">
                <div className="flex flex-col items-center text-center space-y-6">
                  <div className="w-20 h-20 bg-orange-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
                    <svg className="w-10 h-10 text-white" fill="currentColor" viewBox="0 0 24 24">
                      <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" fill="none" />
                      <circle cx="12" cy="12" r="6" stroke="currentColor" strokeWidth="2" fill="none" />
                      <circle cx="12" cy="12" r="2" fill="currentColor" />
                      <path d="M3 7h18M3 17h18" stroke="currentColor" strokeWidth="1" />
                    </svg>
                  </div>

                  <div className="space-y-3">
                    <h3 className="text-2xl font-bold text-orange-800">DEPOSITO GOMME</h3>
                    <p className="text-orange-700">Gestisci il deposito stagionale dei pneumatici</p>
                  </div>

                  <Button className="w-full h-12 text-lg font-semibold bg-orange-600 hover:bg-orange-700 text-white">
                    Gestisci Deposito
                  </Button>
                </div>
              </CardContent>
            </Card>
          </Link>
        </div>

        {/* Quick Stats */}
        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-white border border-gray-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">{vehicles.length}</div>
              <div className="text-sm text-gray-600">Veicoli</div>
            </CardContent>
          </Card>

          <Card className="bg-white border border-gray-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">0</div>
              <div className="text-sm text-gray-600">Set Invernali</div>
            </CardContent>
          </Card>

          <Card className="bg-white border border-gray-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-orange-600">0</div>
              <div className="text-sm text-gray-600">Set Estivi</div>
            </CardContent>
          </Card>

          <Card className="bg-white border border-gray-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">0</div>
              <div className="text-sm text-gray-600">Cambi Totali</div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
