"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import Link from "next/link"
import { useParams } from "next/navigation"

interface Customer {
  firstName: string
  lastName: string
  email: string
  phone: string
}

interface Vehicle {
  id: string
  licensePlate: string
  make: string
  model: string
  year: string
}

interface TireDeposit {
  id: string
  customerId: string
  vehicleId?: string
  licensePlate?: string
  source: "purchased" | "service_removal"
  season: "winter" | "summer"
  brand: string
  size: string
  tireCode: string
  position: string
  dotCode: string
  year: string
  treadDepth: string
  condition: "ottimo" | "buono" | "discreto" | "usurato"
  price?: string
  notes?: string
  depositDate: string
  status: "depositato" | "ritirato" | "venduto" | "smaltito"
  storageLocation: string
}

export default function StorageTiresPage() {
  const params = useParams()
  const customerId = params.id as string
  const [customer, setCustomer] = useState<Customer | null>(null)
  const [vehicles, setVehicles] = useState<Vehicle[]>([])
  const [activeTab, setActiveTab] = useState<"new" | "list">("new")
  const [depositType, setDepositType] = useState<"purchased" | "service_removal">("service_removal")
  const [deposits, setDeposits] = useState<TireDeposit[]>([])

  const [formData, setFormData] = useState({
    vehicleId: "",
    licensePlate: "",
    season: "winter" as "winter" | "summer",
    brand: "",
    size: "",
    tireCode: "",
    position: "A6",
    dotCode: "",
    year: "2024",
    treadDepth: "",
    condition: "buono" as "ottimo" | "buono" | "discreto" | "usurato",
    price: "",
    notes: "",
    storageLocation: "",
  })

  useEffect(() => {
    // Load customer data
    const customerData = localStorage.getItem(`customer_${customerId}`)
    if (customerData) {
      setCustomer(JSON.parse(customerData))
    }

    // Load vehicles
    const vehiclesData = localStorage.getItem(`vehicles_${customerId}`)
    if (vehiclesData) {
      setVehicles(JSON.parse(vehiclesData))
    }

    // Load existing deposits
    const depositsData = localStorage.getItem(`tire_deposits_${customerId}`)
    if (depositsData) {
      setDeposits(JSON.parse(depositsData))
    }
  }, [customerId])

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))

    // Auto-fill license plate when vehicle is selected
    if (field === "vehicleId" && value) {
      const selectedVehicle = vehicles.find((v) => v.id === value)
      if (selectedVehicle) {
        setFormData((prev) => ({ ...prev, licensePlate: selectedVehicle.licensePlate }))
      }
    }
  }

  const handleSaveDeposit = () => {
    const newDeposit: TireDeposit = {
      id: Date.now().toString(),
      customerId,
      vehicleId: depositType === "service_removal" ? formData.vehicleId : undefined,
      licensePlate: formData.licensePlate,
      source: depositType,
      season: formData.season,
      brand: formData.brand,
      size: formData.size,
      tireCode: formData.tireCode,
      position: formData.position,
      dotCode: formData.dotCode,
      year: formData.year,
      treadDepth: formData.treadDepth,
      condition: formData.condition,
      price: formData.price,
      notes: formData.notes,
      depositDate: new Date().toISOString(),
      status: "depositato",
      storageLocation:
        formData.storageLocation ||
        `Scaffale ${formData.season === "winter" ? "A" : "B"}-${Math.floor(Math.random() * 50) + 1}`,
    }

    const updatedDeposits = [...deposits, newDeposit]
    setDeposits(updatedDeposits)
    localStorage.setItem(`tire_deposits_${customerId}`, JSON.stringify(updatedDeposits))

    // Reset form
    setFormData({
      vehicleId: "",
      licensePlate: "",
      season: "winter",
      brand: "",
      size: "",
      tireCode: "",
      position: "A6",
      dotCode: "",
      year: "2024",
      treadDepth: "",
      condition: "buono",
      price: "",
      notes: "",
      storageLocation: "",
    })

    alert("Deposito pneumatico salvato con successo!")
    setActiveTab("list")
  }

  const updateDepositStatus = (depositId: string, newStatus: TireDeposit["status"]) => {
    const updatedDeposits = deposits.map((deposit) =>
      deposit.id === depositId ? { ...deposit, status: newStatus } : deposit,
    )
    setDeposits(updatedDeposits)
    localStorage.setItem(`tire_deposits_${customerId}`, JSON.stringify(updatedDeposits))
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "depositato":
        return "bg-green-100 text-green-800 border-green-300"
      case "ritirato":
        return "bg-blue-100 text-blue-800 border-blue-300"
      case "venduto":
        return "bg-purple-100 text-purple-800 border-purple-300"
      case "smaltito":
        return "bg-red-100 text-red-800 border-red-300"
      default:
        return "bg-gray-100 text-gray-800 border-gray-300"
    }
  }

  const getSourceLabel = (source: string) => {
    return source === "purchased" ? "Acquistato" : "Rimosso da Servizio"
  }

  if (!customer) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-orange-100 flex items-center justify-center">
        <div className="text-center text-white space-y-4">
          <h2 className="text-xl font-semibold mb-4">Caricamento...</h2>
          <Link href="/change">
            <Button variant="outline">Torna al Cambio</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-orange-100">
      {/* Header */}
      <div className="bg-card border-b border-border">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href={`/customer/${customerId}/dashboard`}>
                <Button variant="outline" size="sm">
                  ← Dashboard Cliente
                </Button>
              </Link>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-orange-600 rounded-full flex items-center justify-center">
                  <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" fill="none" />
                    <circle cx="12" cy="12" r="6" stroke="currentColor" strokeWidth="2" fill="none" />
                    <circle cx="12" cy="12" r="2" fill="currentColor" />
                  </svg>
                </div>
                <div>
                  <h1 className="text-xl font-bold text-primary">Deposito Pneumatici</h1>
                  <p className="text-sm text-muted-foreground">
                    {customer.firstName} {customer.lastName}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-4">
        {/* Tab Navigation */}
        <div className="flex gap-2 mb-6">
          <Button
            variant={activeTab === "new" ? "default" : "outline"}
            onClick={() => setActiveTab("new")}
            className="flex items-center gap-2"
          >
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
              <path d="M19 13H13V19H11V13H5V11H11V5H13V11H19V13Z" />
            </svg>
            Nuovo Deposito
          </Button>
          <Button
            variant={activeTab === "list" ? "default" : "outline"}
            onClick={() => setActiveTab("list")}
            className="flex items-center gap-2"
          >
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
              <path d="M3 13H1V7H3V13ZM3 21H1V15H3V21ZM3 5H1V3C1 2.45 1.45 2 2 2H4V4H3V5ZM13 21H11V3H13V21ZM21 21H19V13H21V21ZM21 11H19V3H21V11Z" />
            </svg>
            Depositi Esistenti ({deposits.length})
          </Button>
        </div>

        {activeTab === "new" && (
          <div className="space-y-6">
            {/* Deposit Type Selection */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <svg className="w-5 h-5 text-orange-600" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2L13.09 8.26L19 7L14.74 12L19 17L13.09 15.74L12 22L10.91 15.74L5 17L9.26 12L5 7L10.91 8.26L12 2Z" />
                  </svg>
                  Tipo di Deposito
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card
                    className={`cursor-pointer transition-all ${depositType === "service_removal" ? "bg-orange-100 border-orange-300" : "bg-gray-50 hover:bg-gray-100"}`}
                    onClick={() => setDepositType("service_removal")}
                  >
                    <CardContent className="p-4 text-center">
                      <div className="w-12 h-12 bg-orange-600 rounded-full flex items-center justify-center mx-auto mb-3">
                        <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5H6.5C5.84 5 5.28 5.42 5.08 6.01L3 12V20C3 20.55 3.45 21 4 21H5C5.55 21 6 20.55 6 20V19H18V20C18 20.55 18.45 21 19 21H20C20.55 21 21 20.55 21 20V12L18.92 6.01Z" />
                        </svg>
                      </div>
                      <h3 className="font-semibold text-orange-800">Rimosso da Veicolo</h3>
                      <p className="text-sm text-orange-600 mt-1">Pneumatici rimossi durante il servizio</p>
                    </CardContent>
                  </Card>

                  <Card
                    className={`cursor-pointer transition-all ${depositType === "purchased" ? "bg-orange-100 border-orange-300" : "bg-gray-50 hover:bg-gray-100"}`}
                    onClick={() => setDepositType("purchased")}
                  >
                    <CardContent className="p-4 text-center">
                      <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-3">
                        <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M7 18C5.9 18 5 18.9 5 20S5.9 22 7 22 9 21.1 9 20 8.1 18 7 18ZM1 2V4H3L6.6 11.59L5.25 14.04C5.09 14.32 5 14.65 5 15C5 16.1 5.9 17 7 17H19V15H7.42C7.28 15 7.17 14.89 7.17 14.75L7.2 14.63L8.1 13H15.55C16.3 13 16.96 12.59 17.3 11.97L20.88 5H5.21L4.27 3H1ZM17 18C15.9 18 15 18.9 15 20S15.9 22 17 22 19 21.1 19 20 18.1 18 17 18Z" />
                        </svg>
                      </div>
                      <h3 className="font-semibold text-green-800">Acquistato dal Cliente</h3>
                      <p className="text-sm text-green-600 mt-1">Pneumatici acquistati direttamente</p>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>

            {/* Tire Information Form */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <svg className="w-5 h-5 text-orange-600" fill="currentColor" viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" fill="none" />
                    <circle cx="12" cy="12" r="6" stroke="currentColor" strokeWidth="2" fill="none" />
                    <circle cx="12" cy="12" r="2" fill="currentColor" />
                  </svg>
                  Informazioni Pneumatico
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {depositType === "service_removal" && (
                    <div className="space-y-2">
                      <Label htmlFor="vehicleId">Veicolo</Label>
                      <Select
                        value={formData.vehicleId}
                        onValueChange={(value) => handleInputChange("vehicleId", value)}
                      >
                        <SelectTrigger className="h-12">
                          <SelectValue placeholder="Seleziona veicolo" />
                        </SelectTrigger>
                        <SelectContent>
                          {vehicles.map((vehicle) => (
                            <SelectItem key={vehicle.id} value={vehicle.id}>
                              {vehicle.licensePlate} - {vehicle.make} {vehicle.model}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  <div className="space-y-2">
                    <Label htmlFor="licensePlate">Targa</Label>
                    <Input
                      id="licensePlate"
                      placeholder="AB123CD"
                      value={formData.licensePlate}
                      onChange={(e) => handleInputChange("licensePlate", e.target.value.toUpperCase())}
                      className="h-12 text-lg font-mono"
                      disabled={depositType === "service_removal" && formData.vehicleId}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="season">Stagione</Label>
                    <Select value={formData.season} onValueChange={(value) => handleInputChange("season", value)}>
                      <SelectTrigger className="h-12">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="winter">❄️ Invernali</SelectItem>
                        <SelectItem value="summer">☀️ Estivi</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="brand">Marca</Label>
                    <Select value={formData.brand} onValueChange={(value) => handleInputChange("brand", value)}>
                      <SelectTrigger className="h-12">
                        <SelectValue placeholder="Seleziona marca" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="michelin">Michelin</SelectItem>
                        <SelectItem value="continental">Continental</SelectItem>
                        <SelectItem value="pirelli">Pirelli</SelectItem>
                        <SelectItem value="bridgestone">Bridgestone</SelectItem>
                        <SelectItem value="goodyear">Goodyear</SelectItem>
                        <SelectItem value="nokian">Nokian</SelectItem>
                        <SelectItem value="dunlop">Dunlop</SelectItem>
                        <SelectItem value="altro">Altro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="size">Misura</Label>
                    <Input
                      id="size"
                      placeholder="205/55R16"
                      value={formData.size}
                      onChange={(e) => handleInputChange("size", e.target.value)}
                      className="h-12"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="tireCode">Codice Pneumatico</Label>
                    <Input
                      id="tireCode"
                      placeholder="FF925AB"
                      value={formData.tireCode}
                      onChange={(e) => handleInputChange("tireCode", e.target.value)}
                      className="h-12"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="position">Posizione</Label>
                    <Select value={formData.position} onValueChange={(value) => handleInputChange("position", value)}>
                      <SelectTrigger className="h-12">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="A6">A6 (Anteriore Sinistro)</SelectItem>
                        <SelectItem value="A5">A5 (Anteriore Destro)</SelectItem>
                        <SelectItem value="P6">P6 (Posteriore Sinistro)</SelectItem>
                        <SelectItem value="P4">P4 (Posteriore Destro)</SelectItem>
                        <SelectItem value="Scorta">Scorta</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="dotCode">Codice DOT</Label>
                    <Input
                      id="dotCode"
                      placeholder="DOT"
                      value={formData.dotCode}
                      onChange={(e) => handleInputChange("dotCode", e.target.value)}
                      className="h-12"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="year">Anno</Label>
                    <Input
                      id="year"
                      placeholder="2024"
                      value={formData.year}
                      onChange={(e) => handleInputChange("year", e.target.value)}
                      className="h-12"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="treadDepth">Battistrada (mm)</Label>
                    <Input
                      id="treadDepth"
                      placeholder="7.0"
                      value={formData.treadDepth}
                      onChange={(e) => handleInputChange("treadDepth", e.target.value)}
                      className="h-12"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="condition">Condizione</Label>
                    <Select value={formData.condition} onValueChange={(value) => handleInputChange("condition", value)}>
                      <SelectTrigger className="h-12">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ottimo">Ottimo</SelectItem>
                        <SelectItem value="buono">Buono</SelectItem>
                        <SelectItem value="discreto">Discreto</SelectItem>
                        <SelectItem value="usurato">Usurato</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {depositType === "purchased" && (
                    <div className="space-y-2">
                      <Label htmlFor="price">Prezzo Acquisto (€)</Label>
                      <Input
                        id="price"
                        placeholder="50.00"
                        value={formData.price}
                        onChange={(e) => handleInputChange("price", e.target.value)}
                        className="h-12"
                        type="number"
                        step="0.01"
                      />
                    </div>
                  )}
                </div>

                <div className="mt-4 space-y-2">
                  <Label htmlFor="notes">Note</Label>
                  <Textarea
                    id="notes"
                    placeholder="Note aggiuntive sul pneumatico..."
                    value={formData.notes}
                    onChange={(e) => handleInputChange("notes", e.target.value)}
                    className="min-h-20"
                  />
                </div>

                <div className="mt-6 flex justify-end">
                  <Button onClick={handleSaveDeposit} className="h-12 px-8 text-lg font-semibold">
                    Salva Deposito
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === "list" && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <svg className="w-5 h-5 text-orange-600" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M3 13H1V7H3V13ZM3 21H1V15H3V21ZM3 5H1V3C1 2.45 1.45 2 2 2H4V4H3V5ZM13 21H11V3H13V21ZM21 21H19V13H21V21ZM21 11H19V3H21V11Z" />
                </svg>
                Depositi Pneumatici ({deposits.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {deposits.map((deposit) => (
                  <Card key={deposit.id} className="bg-orange-50 border-orange-200">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="space-y-2">
                          <div className="flex items-center gap-3">
                            <Badge className="bg-orange-600 text-white font-mono">{deposit.licensePlate}</Badge>
                            <Badge variant="outline" className={getStatusColor(deposit.status)}>
                              {deposit.status.charAt(0).toUpperCase() + deposit.status.slice(1)}
                            </Badge>
                            <Badge variant="outline" className="text-xs">
                              {deposit.season === "winter" ? "❄️ Invernali" : "☀️ Estivi"}
                            </Badge>
                            <Badge variant="outline" className="text-xs bg-blue-50 text-blue-700">
                              {getSourceLabel(deposit.source)}
                            </Badge>
                          </div>

                          <div className="text-sm text-muted-foreground">
                            <span className="font-medium">{deposit.brand}</span> • {deposit.size} • Pos:{" "}
                            {deposit.position} • Codice: {deposit.tireCode} • Battistrada: {deposit.treadDepth}mm •
                            Condizione: {deposit.condition}
                          </div>

                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span>Depositato: {new Date(deposit.depositDate).toLocaleDateString("it-IT")}</span>
                            <span>Posizione: {deposit.storageLocation}</span>
                            {deposit.price && <span>Prezzo: €{deposit.price}</span>}
                          </div>

                          {deposit.notes && (
                            <div className="text-xs text-blue-600 bg-blue-50 px-2 py-1 rounded">
                              Note: {deposit.notes}
                            </div>
                          )}
                        </div>

                        <div className="flex gap-2">
                          {deposit.status === "depositato" && (
                            <>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => updateDepositStatus(deposit.id, "ritirato")}
                                className="text-blue-600 border-blue-300"
                              >
                                Ritira
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => updateDepositStatus(deposit.id, "venduto")}
                                className="text-purple-600 border-purple-300"
                              >
                                Vendi
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => updateDepositStatus(deposit.id, "smaltito")}
                                className="text-red-600 border-red-300"
                              >
                                Smaltisci
                              </Button>
                            </>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}

                {deposits.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    <svg className="w-12 h-12 mx-auto mb-4 opacity-50" fill="currentColor" viewBox="0 0 24 24">
                      <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" fill="none" />
                      <circle cx="12" cy="12" r="6" stroke="currentColor" strokeWidth="2" fill="none" />
                      <circle cx="12" cy="12" r="2" fill="currentColor" />
                    </svg>
                    <p>Nessun deposito pneumatico trovato</p>
                    <p className="text-sm">Aggiungi il primo deposito usando il tab "Nuovo Deposito"</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
