import type React from "react"
import type { Metadata } from "next"
import "./globals.css"

export const metadata: Metadata = {
  title: "Tires Pro - Gestione Deposito Pneumatici",
  description: "App professionale per la gestione del deposito pneumatici stagionali by BIT Solution",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  if (typeof window !== 'undefined') {
    console.log("[v0] Layout mounted - checking styles")
    console.log("[v0] Document stylesheets count:", document.styleSheets.length)
    console.log("[v0] Body classes:", document.body.className)
    
    // Check if Tailwind styles are loaded
    setTimeout(() => {
      const testDiv = document.createElement('div')
      testDiv.className = 'bg-blue-500'
      document.body.appendChild(testDiv)
      const bgColor = window.getComputedStyle(testDiv).backgroundColor
      console.log("[v0] Tailwind test - bg-blue-500 computed color:", bgColor)
      document.body.removeChild(testDiv)
    }, 100)
  }
  
  return (
    <html lang="it">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700;900&family=Open+Sans:wght@400;500;600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="antialiased font-sans bg-white text-black min-h-screen">
        <div className="min-h-screen">{children}</div>
      </body>
    </html>
  )
}
