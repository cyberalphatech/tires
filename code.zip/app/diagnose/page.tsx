"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Database, CheckCircle, XCircle, AlertCircle } from "lucide-react"
import Link from "next/link"

export default function DiagnosePage() {
  const [results, setResults] = useState<any>(null)
  const [loading, setLoading] = useState(false)

  const runDiagnostic = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/diagnose-vehicles")
      const data = await response.json()
      setResults(data)
    } catch (error) {
      console.error("Diagnostic failed:", error)
      setResults({ error: "Failed to run diagnostic" })
    } finally {
      setLoading(false)
    }
  }

  const getStatusIcon = (status: boolean | null) => {
    if (status === true) return <CheckCircle className="h-5 w-5 text-green-600" />
    if (status === false) return <XCircle className="h-5 w-5 text-red-600" />
    return <AlertCircle className="h-5 w-5 text-yellow-600" />
  }

  const getStatusBadge = (status: boolean | null, trueText: string, falseText: string) => {
    if (status === true)
      return (
        <Badge variant="default" className="bg-green-100 text-green-800">
          {trueText}
        </Badge>
      )
    if (status === false) return <Badge variant="destructive">{falseText}</Badge>
    return <Badge variant="secondary">Unknown</Badge>
  }

  return (
    <div className="min-h-screen bg-white p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <Link href="/dashboard">
            <Button variant="outline" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Dashboard
            </Button>
          </Link>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Database Diagnostic</h1>
            <p className="text-gray-600">Diagnose the persistent vehicles API 500 error</p>
          </div>
        </div>

        {/* Run Diagnostic Button */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              Vehicle Database Diagnostic
            </CardTitle>
            <CardDescription>
              This tool will check your database structure and identify the cause of the vehicles API 500 error.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={runDiagnostic} disabled={loading} className="w-full">
              {loading ? "Running Diagnostic..." : "Run Diagnostic"}
            </Button>
          </CardContent>
        </Card>

        {/* Results */}
        {results && (
          <div className="space-y-4">
            {/* Connection Status */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    {getStatusIcon(results.database_connection)}
                    Database Connection
                  </span>
                  {getStatusBadge(results.database_connection, "Connected", "Failed")}
                </CardTitle>
              </CardHeader>
              {results.error_details && !results.database_connection && (
                <CardContent>
                  <div className="bg-red-50 p-4 rounded-lg">
                    <p className="text-red-800 font-medium">Connection Error:</p>
                    <p className="text-red-700">{results.error_details.message}</p>
                  </div>
                </CardContent>
              )}
            </Card>

            {/* Table Existence */}
            <Card>
              <CardHeader>
                <CardTitle>Table Status</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    {getStatusIcon(results.vehicles_table_exists)}
                    Vehicles Table
                  </span>
                  {getStatusBadge(results.vehicles_table_exists, "Exists", "Missing")}
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    {getStatusIcon(results.clients_table_exists)}
                    Clients Table
                  </span>
                  {getStatusBadge(results.clients_table_exists, "Exists", "Missing")}
                </div>
              </CardContent>
            </Card>

            {/* Table Structure */}
            {results.vehicles_table_structure && (
              <Card>
                <CardHeader>
                  <CardTitle>Vehicles Table Structure</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left p-2">Field</th>
                          <th className="text-left p-2">Type</th>
                          <th className="text-left p-2">Null</th>
                          <th className="text-left p-2">Key</th>
                          <th className="text-left p-2">Default</th>
                        </tr>
                      </thead>
                      <tbody>
                        {results.vehicles_table_structure.map((column: any, index: number) => (
                          <tr key={index} className="border-b">
                            <td className="p-2 font-medium">{column.Field}</td>
                            <td className="p-2">{column.Type}</td>
                            <td className="p-2">{column.Null}</td>
                            <td className="p-2">{column.Key}</td>
                            <td className="p-2">{column.Default || "NULL"}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Test Insertion */}
            <Card>
              <CardHeader>
                <CardTitle>Test Vehicle Insertion</CardTitle>
              </CardHeader>
              <CardContent>
                <div
                  className={`p-4 rounded-lg ${
                    results.test_insertion?.includes("SUCCESS")
                      ? "bg-green-50"
                      : results.test_insertion?.includes("FAILED")
                        ? "bg-red-50"
                        : "bg-yellow-50"
                  }`}
                >
                  <p
                    className={`font-medium ${
                      results.test_insertion?.includes("SUCCESS")
                        ? "text-green-800"
                        : results.test_insertion?.includes("FAILED")
                          ? "text-red-800"
                          : "text-yellow-800"
                    }`}
                  >
                    {results.test_insertion || "Not attempted"}
                  </p>
                  {results.error_details && results.test_insertion?.includes("FAILED") && (
                    <div className="mt-2 text-red-700">
                      <p>
                        <strong>Error Code:</strong> {results.error_details.code}
                      </p>
                      <p>
                        <strong>SQL State:</strong> {results.error_details.sqlState}
                      </p>
                      <p>
                        <strong>Message:</strong> {results.error_details.sqlMessage || results.error_details.message}
                      </p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Timestamp */}
            <Card>
              <CardContent className="pt-6">
                <p className="text-sm text-gray-500">
                  Diagnostic completed at: {new Date(results.timestamp).toLocaleString()}
                </p>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
