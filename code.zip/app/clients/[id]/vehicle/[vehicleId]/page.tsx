"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { ArrowLeft, Car, Wrench, Package, Truck, Calendar, MapPin, User } from "lucide-react"

interface VehicleDetails {
  id: number
  license_plate: string
  make: string
  model: string
  year: number
  fuel_type: string
  color: string
  current_km: number
  image_urls: string
  client: {
    id: number
    first_name: string
    last_name: string
    client_code: string
  }
  tiresOnboard: Array<{
    id: number
    brand: string
    model: string
    size: string
    season: string
    position: string
    condition: string
    tread_depth: number
    installation_date: string
  }>
  tiresStored: Array<{
    id: number
    brand: string
    model: string
    size: string
    season: string
    condition: string
    tread_depth: number
    storage_location: string
    storage_date: string
    deposit_type: string
  }>
  tiresDispatched: Array<{
    id: number
    brand: string
    model: string
    size: string
    season: string
    condition: string
    removal_date: string
    dispatch_location: string
  }>
}

export default function VehicleDetailPage({
  params,
}: {
  params: { id: string; vehicleId: string }
}) {
  const [vehicle, setVehicle] = useState<VehicleDetails | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    fetchVehicleDetails()
  }, [params.vehicleId])

  const fetchVehicleDetails = async () => {
    try {
      const response = await fetch(`/api/clients/${params.id}/vehicle/${params.vehicleId}/details`)
      if (!response.ok) {
        throw new Error("Failed to fetch vehicle details")
      }
      const data = await response.json()
      setVehicle(data)
    } catch (error) {
      console.error("Error fetching vehicle details:", error)
      setError("Errore nel caricamento dei dettagli veicolo")
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Caricamento dettagli veicolo...</p>
        </div>
      </div>
    )
  }

  if (error || !vehicle) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <Card className="max-w-md mx-auto border-red-200 bg-white">
          <CardContent className="p-6 text-center">
            <p className="text-red-600 mb-4">{error || "Veicolo non trovato"}</p>
            <Link href={`/clients/${params.id}`}>
              <Button variant="outline" className="bg-transparent">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Torna al Cliente
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href={`/clients/${params.id}`}>
                <Button variant="outline" size="sm" className="border-gray-300 bg-transparent">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Cliente
                </Button>
              </Link>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gray-600 rounded-full flex items-center justify-center">
                  <Car className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">{vehicle.license_plate}</h1>
                  <p className="text-sm text-gray-600">
                    {vehicle.make} {vehicle.model} ({vehicle.year})
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto p-6">
        {/* Vehicle Information */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <Card className="bg-white border-gray-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-gray-900">
                <Car className="w-5 h-5" />
                Informazioni Veicolo
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-500">Targa:</span>
                  <p className="font-semibold text-gray-900">{vehicle.license_plate}</p>
                </div>
                <div>
                  <span className="text-gray-500">Marca:</span>
                  <p className="font-semibold text-gray-900">{vehicle.make}</p>
                </div>
                <div>
                  <span className="text-gray-500">Modello:</span>
                  <p className="font-semibold text-gray-900">{vehicle.model}</p>
                </div>
                <div>
                  <span className="text-gray-500">Anno:</span>
                  <p className="font-semibold text-gray-900">{vehicle.year}</p>
                </div>
                <div>
                  <span className="text-gray-500">Carburante:</span>
                  <p className="font-semibold text-gray-900">{vehicle.fuel_type}</p>
                </div>
                <div>
                  <span className="text-gray-500">Colore:</span>
                  <p className="font-semibold text-gray-900">{vehicle.color}</p>
                </div>
                <div>
                  <span className="text-gray-500">Chilometraggio:</span>
                  <p className="font-semibold text-gray-900">{vehicle.current_km?.toLocaleString()} km</p>
                </div>
              </div>
              <div className="flex items-center gap-2 text-sm pt-2 border-t">
                <User className="w-4 h-4 text-gray-500" />
                <span className="text-gray-900">
                  Proprietario: {vehicle.client.first_name} {vehicle.client.last_name}
                </span>
              </div>
            </CardContent>
          </Card>

          {/* Vehicle Image */}
          <Card className="bg-white border-gray-200">
            <CardHeader>
              <CardTitle className="text-gray-900">Foto Veicolo</CardTitle>
            </CardHeader>
            <CardContent>
              {vehicle.image_urls ? (
                <img
                  src={vehicle.image_urls || "/placeholder.svg"}
                  alt={`${vehicle.make} ${vehicle.model}`}
                  className="w-full h-48 object-cover rounded-lg border border-gray-200"
                />
              ) : (
                <div className="w-full h-48 bg-gray-100 rounded-lg border border-gray-200 flex items-center justify-center">
                  <Car className="w-12 h-12 text-gray-400" />
                  <span className="ml-2 text-gray-500">Nessuna foto disponibile</span>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Tires Sections */}
        <div className="space-y-6">
          {/* Tires Onboard */}
          <Card className="bg-white border-gray-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-gray-900">
                <Wrench className="w-5 h-5" />
                Pneumatici Montati ({vehicle.tiresOnboard?.length || 0})
              </CardTitle>
            </CardHeader>
            <CardContent>
              {!vehicle.tiresOnboard || vehicle.tiresOnboard.length === 0 ? (
                <div className="text-center py-8">
                  <Wrench className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">Nessun pneumatico montato</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {vehicle.tiresOnboard.map((tire) => (
                    <Card key={tire.id} className="border border-green-200 bg-green-50">
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between mb-2">
                          <Badge variant="secondary" className="bg-green-100 text-green-700">
                            {tire.position}
                          </Badge>
                          <Badge
                            variant="outline"
                            className={`${
                              tire.season === "winter"
                                ? "border-blue-300 text-blue-700"
                                : tire.season === "summer"
                                  ? "border-orange-300 text-orange-700"
                                  : "border-gray-300 text-gray-700"
                            }`}
                          >
                            {tire.season}
                          </Badge>
                        </div>
                        <h4 className="font-semibold text-sm text-gray-900">{tire.brand}</h4>
                        <p className="text-xs text-gray-600">{tire.size}</p>
                        <p className="text-xs text-gray-600">Battistrada: {tire.tread_depth}mm</p>
                        <p className="text-xs text-gray-600">Condizione: {tire.condition}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Tires Stored */}
          <Card className="bg-white border-gray-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-gray-900">
                <Package className="w-5 h-5" />
                Pneumatici in Deposito ({vehicle.tiresStored?.length || 0})
              </CardTitle>
            </CardHeader>
            <CardContent>
              {!vehicle.tiresStored || vehicle.tiresStored.length === 0 ? (
                <div className="text-center py-8">
                  <Package className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">Nessun pneumatico in deposito</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {vehicle.tiresStored.map((tire) => (
                    <Card key={tire.id} className="border border-blue-200 bg-blue-50">
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-semibold text-sm text-gray-900">{tire.brand}</h4>
                          <Badge
                            variant="outline"
                            className={`${
                              tire.season === "winter"
                                ? "border-blue-300 text-blue-700"
                                : tire.season === "summer"
                                  ? "border-orange-300 text-orange-700"
                                  : "border-gray-300 text-gray-700"
                            }`}
                          >
                            {tire.season}
                          </Badge>
                        </div>
                        <p className="text-xs text-gray-600">{tire.size}</p>
                        <p className="text-xs text-gray-600">Battistrada: {tire.tread_depth}mm</p>
                        <p className="text-xs text-gray-600">Condizione: {tire.condition}</p>
                        <div className="mt-2 pt-2 border-t border-blue-200">
                          <p className="text-xs text-gray-500">
                            <MapPin className="w-3 h-3 inline mr-1" />
                            {tire.storage_location}
                          </p>
                          <p className="text-xs text-gray-500">
                            <Calendar className="w-3 h-3 inline mr-1" />
                            {new Date(tire.storage_date).toLocaleDateString("it-IT")}
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Tires Dispatched */}
          <Card className="bg-white border-gray-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-gray-900">
                <Truck className="w-5 h-5" />
                Pneumatici Consegnati ({vehicle.tiresDispatched?.length || 0})
              </CardTitle>
            </CardHeader>
            <CardContent>
              {!vehicle.tiresDispatched || vehicle.tiresDispatched.length === 0 ? (
                <div className="text-center py-8">
                  <Truck className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">Nessun pneumatico consegnato</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {vehicle.tiresDispatched.map((tire) => (
                    <Card key={tire.id} className="border border-gray-300 bg-gray-50">
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-semibold text-sm text-gray-900">{tire.brand}</h4>
                          <Badge
                            variant="outline"
                            className={`${
                              tire.season === "winter"
                                ? "border-blue-300 text-blue-700"
                                : tire.season === "summer"
                                  ? "border-orange-300 text-orange-700"
                                  : "border-gray-300 text-gray-700"
                            }`}
                          >
                            {tire.season}
                          </Badge>
                        </div>
                        <p className="text-xs text-gray-600">{tire.size}</p>
                        <p className="text-xs text-gray-600">Condizione: {tire.condition}</p>
                        <div className="mt-2 pt-2 border-t border-gray-300">
                          <p className="text-xs text-gray-500">
                            <Calendar className="w-3 h-3 inline mr-1" />
                            Consegnato: {new Date(tire.removal_date).toLocaleDateString("it-IT")}
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
