"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"

interface TirePosition {
  position: string
  dot: string
  year: string
  treadDepth: string
  condition: string
  storageLocation: string
  currentKm: string
  maxKmBeforeTrash: string
  kmHistory: { date: string; km: string; notes: string }[]
}

interface WinterTire {
  id: number
  client_id: number
  vehicle_id: number
  tire_code: string
  brand: string
  size: string
  position: string
  season: string
  dot_code: string
  manufacture_year: number
  tread_depth: number
  condition_rating: string
  warehouse_location: string
  status: string
  first_name: string
  last_name: string
  license_plate: string
  make: string
  model: string
  year: number
  created_at: string
}

export default function WinterTirePage() {
  const [activeTab, setActiveTab] = useState<"deposit" | "list" | "management">("deposit")
  const [loading, setLoading] = useState(false)
  const [bodyshopId, setBodyshopId] = useState<string>("1") // This should come from auth context
  const [winterTires, setWinterTires] = useState<WinterTire[]>([])
  const [clients, setClients] = useState<any[]>([])

  const [tireData, setTireData] = useState({
    plateNumber: "",
    tireCode: "",
    kilometers: "",
    brand: "",
    size: "",
    loadIndex: "",
    speedRating: "",
  })

  useEffect(() => {
    fetchWinterTires()
    fetchClients()
  }, [bodyshopId])

  const fetchWinterTires = async () => {
    try {
      setLoading(true)
      const response = await fetch(`/api/bodyshop/${bodyshopId}/tires?season=winter`)
      if (response.ok) {
        const data = await response.json()
        setWinterTires(data)
      }
    } catch (error) {
      console.error("Error fetching winter tires:", error)
    } finally {
      setLoading(false)
    }
  }

  const fetchClients = async () => {
    try {
      const response = await fetch(`/api/bodyshop/${bodyshopId}/clients`)
      if (response.ok) {
        const data = await response.json()
        setClients(data)
      }
    } catch (error) {
      console.error("Error fetching clients:", error)
    }
  }

  const getPositionDescription = (position: string): string => {
    const positionMap: { [key: string]: string } = {
      AS: "Anteriore Sinistro",
      AD: "Anteriore Destro",
      PS: "Posteriore Sinistro",
      PD: "Posteriore Destro",
      ET: "Extra Tire",
      A6: "Anteriore Sinistro",
      A5: "Anteriore Destro",
      P6: "Posteriore Sinistro",
      P4: "Posteriore Destro",
    }
    return positionMap[position] || position
  }

  const [tirePositions, setTirePositions] = useState<TirePosition[]>([
    {
      position: "AS",
      dot: "DOT",
      year: "2024",
      treadDepth: "8.0",
      condition: "Buono",
      storageLocation: "Scaffale A1",
      currentKm: "15000",
      maxKmBeforeTrash: "50000",
      kmHistory: [
        { date: "2024-11-01", km: "12000", notes: "Montaggio invernale" },
        { date: "2024-11-15", km: "15000", notes: "Controllo mensile" },
      ],
    },
    {
      position: "AD",
      dot: "DOT",
      year: "2024",
      treadDepth: "7.5",
      condition: "Buono",
      storageLocation: "Scaffale A1",
      currentKm: "15000",
      maxKmBeforeTrash: "50000",
      kmHistory: [{ date: "2024-11-01", km: "12000", notes: "Montaggio invernale" }],
    },
    {
      position: "PS",
      dot: "DOT",
      year: "2024",
      treadDepth: "8.0",
      condition: "Buono",
      storageLocation: "Scaffale A2",
      currentKm: "15000",
      maxKmBeforeTrash: "50000",
      kmHistory: [],
    },
    {
      position: "PD",
      dot: "DOT",
      year: "2024",
      treadDepth: "7.8",
      condition: "Buono",
      storageLocation: "Scaffale A2",
      currentKm: "15000",
      maxKmBeforeTrash: "50000",
      kmHistory: [],
    },
  ])

  const getStoredWinterTires = () => {
    return winterTires.filter((tire) => tire.status === "stored")
  }

  const getClientInventory = () => {
    const inventory = clients.map((client) => ({
      id: client.id,
      clientName: `${client.first_name} ${client.last_name}`,
      winterTires: winterTires.filter((tire) => tire.client_id === client.id && tire.season === "winter").length,
      condition: "Buono", // This could be calculated from tire conditions
      vehicleCount: client.vehicle_count || 0,
    }))
    return inventory.filter((item) => item.winterTires > 0)
  }

  const getScrappedTires = () => {
    return winterTires.filter((tire) => tire.status === "scrapped")
  }

  const handleInputChange = (field: string, value: string) => {
    setTireData((prev) => ({ ...prev, [field]: value }))
  }

  const handleTirePositionChange = (index: number, field: keyof TirePosition, value: string) => {
    setTirePositions((prev) => prev.map((tire, i) => (i === index ? { ...tire, [field]: value } : tire)))
  }

  const handleSaveDeposit = async () => {
    try {
      setLoading(true)
      // Here you would save the tire deposit data to the API
      // For now, just show success message
      alert("Deposito pneumatici invernali salvato con successo!")
      await fetchWinterTires() // Refresh data
    } catch (error) {
      console.error("Error saving deposit:", error)
      alert("Errore nel salvare il deposito")
    } finally {
      setLoading(false)
    }
  }

  if (loading && winterTires.length === 0) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Caricamento pneumatici invernali...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href="/dashboard">
                <Button variant="outline" size="sm" className="border-gray-300 bg-transparent">
                  ← Dashboard
                </Button>
              </Link>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                  <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2L13.09 8.26L19 7L14.74 12L19 17L13.09 15.74L12 22L10.91 15.74L5 17L9.26 12L5 7L10.91 8.26L12 2Z" />
                  </svg>
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900">Gestione Pneumatici Invernali</h1>
                  <p className="text-sm text-gray-600">Deposito e gestione gomme invernali</p>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-4 text-sm text-gray-600">
              <span>
                Totale Invernali: <strong className="text-blue-600">{winterTires.length}</strong>
              </span>
              <span>
                Depositati: <strong className="text-green-600">{getStoredWinterTires().length}</strong>
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-4">
        {/* Tab Navigation */}
        <div className="flex gap-2 mb-6">
          <Button
            variant={activeTab === "deposit" ? "default" : "outline"}
            onClick={() => setActiveTab("deposit")}
            className="flex items-center gap-2"
          >
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
              <path d="M19 13H13V19H11V13H5V11H11V5H13V11H19V13Z" />
            </svg>
            Nuovo Deposito
          </Button>
          <Button
            variant={activeTab === "list" ? "default" : "outline"}
            onClick={() => setActiveTab("list")}
            className="flex items-center gap-2"
          >
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
              <path d="M3 13H1V7H3V13ZM3 21H1V15H3V21ZM3 5H1V3C1 2.45 1.45 2 2 2H4V4H3V5ZM13 21H11V3H13V21ZM21 21H19V13H21V21ZM21 11H19V3H21V11Z" />
            </svg>
            Depositi Esistenti ({getStoredWinterTires().length})
          </Button>
          <Button
            variant={activeTab === "management" ? "default" : "outline"}
            onClick={() => setActiveTab("management")}
            className="flex items-center gap-2"
          >
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2L2 7L12 12L22 7L12 2ZM2 17L12 22L22 17M2 12L12 17L22 12" />
            </svg>
            Gestione Cambio
          </Button>
        </div>

        {activeTab === "deposit" && (
          <div className="space-y-6">
            {/* Vehicle and Tire Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <svg className="w-5 h-5 text-blue-600" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5H6.5C5.84 5 5.28 5.42 5.08 6.01L3 12V20C3 20.55 3.45 21 4 21H5C5.55 21 6 20.55 6 20V19H18V20C18 20.55 18.45 21 19 21H20C20.55 21 21 20.55 21 20V12L18.92 6.01ZM6.5 16C5.67 16 5 15.33 5 14.5S5.67 13 6.5 13 8 13.67 8 14.5 7.33 16 6.5 16ZM17.5 16C16.67 16 16 15.33 16 14.5S16.67 13 17.5 13 19 13.67 19 14.5 18.33 16 17.5 16ZM5 11L6.5 6.5H17.5L19 11H5Z" />
                  </svg>
                  Informazioni Veicolo e Pneumatici
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="plateNumber">Targa</Label>
                    <Input
                      id="plateNumber"
                      placeholder="AB123CD"
                      value={tireData.plateNumber}
                      onChange={(e) => handleInputChange("plateNumber", e.target.value)}
                      className="h-12 text-lg font-mono bg-white text-gray-900 border-gray-300"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="tireCode">Codice Pneumatico</Label>
                    <Input
                      id="tireCode"
                      placeholder="FF925AB"
                      value={tireData.tireCode}
                      onChange={(e) => handleInputChange("tireCode", e.target.value)}
                      className="h-12 bg-white text-gray-900 border-gray-300"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="kilometers">Chilometraggio</Label>
                    <Input
                      id="kilometers"
                      placeholder="10000"
                      value={tireData.kilometers}
                      onChange={(e) => handleInputChange("kilometers", e.target.value)}
                      className="h-12 bg-white text-gray-900 border-gray-300"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="brand">Marca</Label>
                    <Select onValueChange={(value) => handleInputChange("brand", value)}>
                      <SelectTrigger className="h-12 bg-white text-gray-900 border-gray-300">
                        <SelectValue placeholder="Seleziona marca" />
                      </SelectTrigger>
                      <SelectContent className="bg-white">
                        <SelectItem value="michelin">Michelin</SelectItem>
                        <SelectItem value="continental">Continental</SelectItem>
                        <SelectItem value="pirelli">Pirelli</SelectItem>
                        <SelectItem value="bridgestone">Bridgestone</SelectItem>
                        <SelectItem value="goodyear">Goodyear</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="size">Misura</Label>
                    <Input
                      id="size"
                      placeholder="205/55R16"
                      value={tireData.size}
                      onChange={(e) => handleInputChange("size", e.target.value)}
                      className="h-12 bg-white text-gray-900 border-gray-300"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="loadIndex">Indice di Carico</Label>
                    <Input
                      id="loadIndex"
                      placeholder="91"
                      value={tireData.loadIndex}
                      onChange={(e) => handleInputChange("loadIndex", e.target.value)}
                      className="h-12 bg-white text-gray-900 border-gray-300"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Tire Positions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <svg className="w-5 h-5 text-blue-600" fill="currentColor" viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" fill="none" />
                    <circle cx="12" cy="12" r="6" stroke="currentColor" strokeWidth="2" fill="none" />
                    <circle cx="12" cy="12" r="2" fill="currentColor" />
                  </svg>
                  Posizioni Pneumatici
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {tirePositions.map((tire, index) => (
                    <Card key={index} className="bg-blue-50 border-blue-200">
                      <CardContent className="p-4">
                        <div className="text-center space-y-3">
                          <div className="flex justify-between items-center">
                            <Badge variant="secondary" className="bg-blue-100 text-blue-800 text-xs px-2 py-1">
                              {getPositionDescription(tire.position)}
                            </Badge>
                            <Select
                              value={tire.condition}
                              onValueChange={(value) => handleTirePositionChange(index, "condition", value)}
                            >
                              <SelectTrigger className="w-20 h-8 text-xs bg-white text-gray-900 border-gray-300">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent className="bg-white">
                                <SelectItem value="Ottimo">Ottimo</SelectItem>
                                <SelectItem value="Buono">Buono</SelectItem>
                                <SelectItem value="Discreto">Discreto</SelectItem>
                                <SelectItem value="Usurato">Usurato</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          {/* Tire Visual */}
                          <div className="w-16 h-16 mx-auto bg-blue-600 rounded-full flex items-center justify-center">
                            <svg className="w-10 h-10 text-white" fill="currentColor" viewBox="0 0 24 24">
                              <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" fill="none" />
                              <circle cx="12" cy="12" r="6" stroke="currentColor" strokeWidth="2" fill="none" />
                              <circle cx="12" cy="12" r="2" fill="currentColor" />
                            </svg>
                          </div>

                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <Label className="text-xs">Posizione:</Label>
                              <Input
                                value={tire.storageLocation}
                                onChange={(e) => handleTirePositionChange(index, "storageLocation", e.target.value)}
                                className="h-8 text-xs bg-white text-gray-900 border-gray-300"
                                placeholder="Scaffale A1"
                              />
                            </div>

                            <div className="flex items-center gap-2">
                              <Label className="text-xs">DOT:</Label>
                              <Input
                                value={tire.dot}
                                onChange={(e) => handleTirePositionChange(index, "dot", e.target.value)}
                                className="h-8 text-xs bg-white text-gray-900 border-gray-300"
                              />
                            </div>

                            <div className="flex items-center gap-2">
                              <Label className="text-xs">Anno:</Label>
                              <Input
                                value={tire.year}
                                onChange={(e) => handleTirePositionChange(index, "year", e.target.value)}
                                className="h-8 text-xs bg-white text-gray-900 border-gray-300"
                              />
                            </div>

                            <div className="flex items-center gap-2">
                              <Label className="text-xs">Battistrada:</Label>
                              <Input
                                value={tire.treadDepth}
                                onChange={(e) => handleTirePositionChange(index, "treadDepth", e.target.value)}
                                className="h-8 text-xs bg-white text-gray-900 border-gray-300"
                                placeholder="mm"
                              />
                            </div>

                            <div className="flex items-center gap-2">
                              <Label className="text-xs">Km Attuali:</Label>
                              <Input
                                value={tire.currentKm}
                                onChange={(e) => handleTirePositionChange(index, "currentKm", e.target.value)}
                                className="h-8 text-xs bg-white text-gray-900 border-gray-300"
                                placeholder="15000"
                              />
                            </div>

                            <div className="flex items-center gap-2">
                              <Label className="text-xs">Km Max:</Label>
                              <Input
                                value={tire.maxKmBeforeTrash}
                                onChange={(e) => handleTirePositionChange(index, "maxKmBeforeTrash", e.target.value)}
                                className="h-8 text-xs bg-white text-gray-900 border-gray-300"
                                placeholder="50000"
                              />
                            </div>

                            {tire.kmHistory.length > 0 && (
                              <div className="mt-2 p-2 bg-white rounded border">
                                <Label className="text-xs font-semibold">Storico Km:</Label>
                                <div className="space-y-1 mt-1">
                                  {tire.kmHistory.slice(-2).map((entry, i) => (
                                    <div key={i} className="text-xs text-muted-foreground">
                                      {entry.date}: {entry.km}km - {entry.notes}
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                <div className="mt-6 flex justify-end">
                  <Button
                    onClick={handleSaveDeposit}
                    className="h-12 px-8 text-lg font-semibold bg-gray-800 hover:bg-gray-700 text-white"
                  >
                    Salva Deposito Invernale
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === "list" && (
          <Card className="bg-white border-gray-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <svg className="w-5 h-5 text-blue-600" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M3 13H1V7H3V13ZM3 21H1V15H3V21ZM3 5H1V3C1 2.45 1.45 2 2 2H4V4H3V5ZM13 21H11V3H13V21ZM21 21H19V13H21V21ZM21 11H19V3H21V11Z" />
                </svg>
                Depositi Pneumatici Invernali
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {getStoredWinterTires().length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <svg className="w-12 h-12 mx-auto mb-4 text-gray-300" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2L13.09 8.26L19 7L14.74 12L19 17L13.09 15.74L12 22L10.91 15.74L5 17L9.26 12L5 7L10.91 8.26L12 2Z" />
                    </svg>
                    <p>Nessun pneumatico invernale depositato</p>
                  </div>
                ) : (
                  getStoredWinterTires().map((tire) => (
                    <Card key={tire.id} className="bg-blue-50 border-blue-200">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="space-y-1">
                            <div className="flex items-center gap-3">
                              <Badge className="bg-blue-600 text-white font-mono">{tire.license_plate}</Badge>
                              <span className="font-semibold">
                                {tire.first_name} {tire.last_name}
                              </span>
                              <Badge variant="outline" className="text-green-700 border-green-300">
                                {tire.status === "stored" ? "Depositato" : tire.status}
                              </Badge>
                            </div>
                            <div className="text-sm text-gray-600">
                              {tire.brand} • {tire.size} • Codice: {tire.tire_code} • Posizione:{" "}
                              {getPositionDescription(tire.position)}
                            </div>
                            <div className="text-xs text-gray-500">
                              {tire.make} {tire.model} ({tire.year}) • Battistrada: {tire.tread_depth}mm •{" "}
                              {tire.warehouse_location}
                            </div>
                            <div className="text-xs text-gray-500">
                              Depositato il: {new Date(tire.created_at).toLocaleDateString("it-IT")}
                            </div>
                          </div>

                          <div className="flex gap-2">
                            <Button variant="outline" size="sm" className="border-gray-300 bg-transparent">
                              Visualizza
                            </Button>
                            <Button variant="outline" size="sm" className="text-red-600 border-red-300 bg-transparent">
                              Ritira
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {activeTab === "management" && (
          <div className="space-y-6">
            {/* Quick Actions Menu */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <svg className="w-5 h-5 text-blue-600" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2L2 7L12 12L22 7L12 2Z" />
                  </svg>
                  Azioni Rapide Menu
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Button variant="outline" className="h-16 flex flex-col gap-2 bg-transparent">
                    <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2L13.09 8.26L19 7L14.74 12L19 17L13.09 15.74L12 22L10.91 15.74L5 17L9.26 12L5 7L10.91 8.26L12 2Z" />
                    </svg>
                    Inventario Cliente
                  </Button>
                  <Button variant="outline" className="h-16 flex flex-col gap-2 bg-transparent">
                    <svg className="w-6 h-6 text-blue-600" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2L13.09 8.26L19 7L14.74 12L19 17L13.09 15.74L12 22L10.91 15.74L5 17L9.26 12L5 7L10.91 8.26L12 2Z" />
                    </svg>
                    Invernali Cliente
                  </Button>
                  <Button variant="outline" className="h-16 flex flex-col gap-2 text-gray-600 border-gray-300 bg-white">
                    <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2C6.48 2 2 6.48 2 12S6.48 22 12 22 22 17.52 22 12 17.52 2 12 2Z" />
                    </svg>
                    Estivi Cliente
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Vehicle Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <svg className="w-5 h-5 text-blue-600" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5H6.5C5.84 5 5.28 5.42 5.08 6.01L3 12V20C3 20.55 3.45 21 4 21H5C5.55 21 6 20.55 6 20V19H18V20C18 20.55 18.45 21 19 21H20C20.55 21 21 20.55 21 20V12L18.92 6.01Z" />
                  </svg>
                  Azioni Veicolo
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Button
                    variant="outline"
                    className="h-16 flex flex-col gap-2 text-red-600 border-red-300 bg-transparent"
                  >
                    <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M6 19C6 20.1 6.9 21 8 21H16C17.1 21 18 20.1 18 19V7H6V19ZM19 4H15.5L14.5 3H9.5L8.5 4H5V6H19V4Z" />
                    </svg>
                    Rottama Gomme
                  </Button>
                  <Button
                    variant="outline"
                    className="h-16 flex flex-col gap-2 text-green-600 border-green-300 bg-transparent"
                  >
                    <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2C6.48 2 2 6.48 2 12S6.48 22 12 22 22 17.52 22 12 17.52 2 12 2ZM13 17H11V15H13V17ZM13 13H11V7H13V13Z" />
                    </svg>
                    Cambio Gomme
                  </Button>
                  <Button variant="outline" className="h-16 flex flex-col gap-2 bg-transparent">
                    <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2L2 7L12 12L22 7L12 2ZM2 17L12 22L22 17M2 12L12 17L22 12" />
                    </svg>
                    Deposito Gomme
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Client Inventory Overview */}
            <Card className="bg-white border-gray-200">
              <CardHeader>
                <CardTitle>Inventario Cliente Invernali</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {getClientInventory().length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <p>Nessun inventario invernale disponibile</p>
                    </div>
                  ) : (
                    getClientInventory().map((item) => (
                      <div key={item.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div className="flex items-center gap-4">
                          <Badge className="bg-blue-600 text-white">Invernali</Badge>
                          <span className="font-semibold">{item.clientName}</span>
                          <span className="text-sm text-gray-600">Pneumatici: {item.winterTires}</span>
                          <span className="text-sm text-gray-600">Veicoli: {item.vehicleCount}</span>
                          <Badge variant="outline" className="text-green-700">
                            {item.condition}
                          </Badge>
                        </div>
                        <Button variant="outline" size="sm" className="border-gray-300 bg-transparent">
                          Gestisci
                        </Button>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Scrapped Tires */}
            <Card className="bg-white border-gray-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-600">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M6 19C6 20.1 6.9 21 8 21H16C17.1 21 18 20.1 18 19V7H6V19ZM19 4H15.5L14.5 3H9.5L8.5 4H5V6H19V4Z" />
                  </svg>
                  Gomme Invernali Rottamate
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {getScrappedTires().length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <p>Nessuna gomma invernale rottamata</p>
                    </div>
                  ) : (
                    getScrappedTires().map((tire) => (
                      <div
                        key={tire.id}
                        className="flex items-center justify-between p-4 bg-red-50 rounded-lg border border-red-200"
                      >
                        <div className="flex items-center gap-4">
                          <Badge className="bg-red-600 text-white font-mono">{tire.license_plate}</Badge>
                          <span className="font-semibold">{tire.brand}</span>
                          <span className="text-sm text-gray-600">
                            Cliente: {tire.first_name} {tire.last_name}
                          </span>
                          <span className="text-sm text-gray-600">
                            Rottamato il: {new Date(tire.created_at).toLocaleDateString("it-IT")}
                          </span>
                          <Badge variant="outline" className="text-red-700 border-red-300">
                            Rottamato
                          </Badge>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
