"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function DashboardPage() {
  const router = useRouter()

  const handleLogout = () => {
    localStorage.removeItem("user")
    document.cookie = "auth-token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;"
    router.push("/")
  }

  const navigationItems = [
    {
      title: "INVERNO",
      subtitle: "Gestione pneumatici invernali",
      icon: (
        <svg className="w-12 h-12" fill="currentColor" viewBox="0 0 24 24">
          <path d="M12 2L13.09 8.26L19 7L14.74 12L19 17L13.09 15.74L12 22L10.91 15.74L5 17L9.26 12L5 7L10.91 8.26L12 2Z" />
        </svg>
      ),
      href: "/winter",
      bgColor: "bg-blue-50 hover:bg-blue-100",
      iconColor: "text-blue-600",
    },
    {
      title: "ESTATE",
      subtitle: "Gestione pneumatici estivi",
      icon: (
        <svg className="w-12 h-12" fill="currentColor" viewBox="0 0 24 24">
          <circle cx="12" cy="12" r="5" />
          <path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42" />
        </svg>
      ),
      href: "/summer",
      bgColor: "bg-orange-50 hover:bg-orange-100",
      iconColor: "text-orange-600",
    },
    {
      title: "CLIENTI",
      subtitle: "Gestione clienti e veicoli",
      icon: (
        <svg className="w-12 h-12" fill="currentColor" viewBox="0 0 24 24">
          <path d="M16 7C16 9.21 14.21 11 12 11C9.79 11 8 9.21 8 7C8 4.79 9.79 3 12 3C14.21 3 16 4.79 16 7ZM12 14C16.42 14 20 15.79 20 18V20H4V18C4 15.79 7.58 14 12 14Z" />
        </svg>
      ),
      href: "/clients",
      bgColor: "bg-cyan-50 hover:bg-cyan-100",
      iconColor: "text-cyan-600",
    },
    {
      title: "INVENTARIO",
      subtitle: "Gestione magazzino completo",
      icon: (
        <svg className="w-12 h-12" fill="currentColor" viewBox="0 0 24 24">
          <path d="M19 3H5C3.9 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V5C21 3.9 20.1 3 19 3ZM19 19H5V5H19V19ZM17 12H15V17H17V12ZM13 7H11V17H13V7ZM9 10H7V17H9V10Z" />
        </svg>
      ),
      href: "/inventory",
      bgColor: "bg-green-50 hover:bg-green-100",
      iconColor: "text-green-600",
    },
    {
      title: "LEGGI TARGA",
      subtitle: "Scansione automatica targhe",
      icon: (
        <svg className="w-12 h-12" fill="currentColor" viewBox="0 0 24 24">
          <path d="M9.5 6.5V12.5H14.5V6.5H9.5ZM11 8H13V11H11V8ZM12 2L13.09 8.26L19 7L14.74 12L19 17L13.09 15.74L12 22L10.91 15.74L5 17L9.26 12L5 7L10.91 8.26L12 2Z" />
          <rect x="2" y="4" width="20" height="16" rx="2" stroke="currentColor" strokeWidth="2" fill="none" />
          <rect x="4" y="6" width="16" height="12" rx="1" stroke="currentColor" strokeWidth="1" fill="none" />
        </svg>
      ),
      href: "/plate-reader",
      bgColor: "bg-purple-50 hover:bg-purple-100",
      iconColor: "text-purple-600",
    },
    {
      title: "GESTIONE MEZZI",
      subtitle: "Gestione veicoli e flotte",
      icon: (
        <svg className="w-12 h-12" fill="currentColor" viewBox="0 0 24 24">
          <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5H15V4C15 2.9 14.1 2 13 2H11C9.9 2 9 2.9 9 4V5H6.5C5.84 5 5.28 5.42 5.08 6.01L3 12V20C3 20.55 3.45 21 4 21H5C5.55 21 6 20.55 6 20V19H18V20C18 20.55 18.45 21 19 21H20C20.55 21 21 20.55 21 20V12L18.92 6.01ZM11 4H13V5H11V4ZM6.5 16C5.67 16 5 15.33 5 14.5S5.67 13 6.5 13S8 13.67 8 14.5S7.33 16 6.5 16ZM17.5 16C16.67 16 16 15.33 16 14.5S16.67 13 17.5 13S19 13.67 19 14.5S18.33 16 17.5 16ZM5 11L6.5 7H17.5L19 11H5Z" />
        </svg>
      ),
      href: "/vehicle-management",
      bgColor: "bg-indigo-50 hover:bg-indigo-100",
      iconColor: "text-indigo-600",
    },
  ]

  return (
    <div className="min-h-screen bg-white">
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gray-600 rounded-full flex items-center justify-center">
                <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" fill="none" />
                  <circle cx="12" cy="12" r="6" stroke="currentColor" strokeWidth="2" fill="none" />
                  <circle cx="12" cy="12" r="2" fill="currentColor" />
                </svg>
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Tires Pro</h1>
                <p className="text-sm text-gray-600">Dashboard Principale</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="sm"
                className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
                onClick={() => router.push("/settings")}
              >
                ⚙️ Impostazioni
              </Button>

              <Button
                size="lg"
                className="bg-gray-600 hover:bg-gray-700 text-white font-bold px-6 py-3 text-lg shadow-lg hover:shadow-xl transition-all duration-200"
                onClick={() => router.push("/change")}
              >
                🔄 CAMBIO
              </Button>

              <Button
                variant="outline"
                size="sm"
                className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
                onClick={handleLogout}
              >
                Esci
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto p-4">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Benvenuto nel sistema di gestione</h2>
          <p className="text-gray-600">Seleziona una sezione per iniziare a gestire i pneumatici</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {navigationItems.map((item, index) => (
            <Link key={index} href={item.href}>
              <Card className="bg-white hover:bg-gray-50 border-2 border-gray-200 hover:border-gray-300 transition-all duration-200 cursor-pointer group">
                <CardContent className="p-8">
                  <div className="flex flex-col items-center text-center space-y-4">
                    <div className={`${item.iconColor} group-hover:scale-110 transition-transform duration-200`}>
                      {item.icon}
                    </div>

                    <div className="space-y-2">
                      <h3 className="text-xl font-bold text-gray-900">{item.title}</h3>
                      <p className="text-sm text-gray-600">{item.subtitle}</p>
                    </div>

                    <div className="w-full pt-4">
                      <Button className="w-full h-12 text-lg font-semibold bg-gray-600 hover:bg-gray-700 text-white transition-colors">
                        Apri Sezione
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-white border-gray-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">24</div>
              <div className="text-sm text-gray-600">Set Invernali</div>
            </CardContent>
          </Card>

          <Card className="bg-white border-gray-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-orange-600">18</div>
              <div className="text-sm text-gray-600">Set Estivi</div>
            </CardContent>
          </Card>

          <Card className="bg-white border-gray-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">42</div>
              <div className="text-sm text-gray-600">Totale Depositi</div>
            </CardContent>
          </Card>

          <Card className="bg-white border-gray-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">8</div>
              <div className="text-sm text-gray-600">Cambi Oggi</div>
            </CardContent>
          </Card>
        </div>

        <Card className="mt-8 bg-white border-gray-200">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Attività Recente</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between py-2 border-b border-gray-200">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-sm text-gray-700">Deposito pneumatici invernali - AB123CD</span>
                </div>
                <span className="text-xs text-gray-500">2 ore fa</span>
              </div>

              <div className="flex items-center justify-between py-2 border-b border-gray-200">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span className="text-sm text-gray-700">Ritiro pneumatici estivi - XY789ZW</span>
                </div>
                <span className="text-xs text-gray-500">4 ore fa</span>
              </div>

              <div className="flex items-center justify-between py-2">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                  <span className="text-sm text-gray-700">Nuovo cliente registrato - Officina Bianchi</span>
                </div>
                <span className="text-xs text-gray-500">1 giorno fa</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
