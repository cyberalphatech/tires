"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from "@/components/ui/dialog"
import Link from "next/link"
import { useState, useEffect } from "react"

export default function VehicleManagementPage() {
  const [vehicles, setVehicles] = useState([])
  const [clients, setClients] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [isAddCarOpen, setIsAddCarOpen] = useState(false)
  const [isCreatingClient, setIsCreatingClient] = useState(false)

  const [vehicleForm, setVehicleForm] = useState({
    licensePlate: "",
    brand: "",
    model: "",
    year: "",
    clientId: "",
  })

  const [newClientForm, setNewClientForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
  })

  useEffect(() => {
    fetchVehicles()
    fetchClients()
  }, [])

  const fetchVehicles = async () => {
    try {
      const userData = localStorage.getItem("user")
      if (!userData) return

      const user = JSON.parse(userData)
      const bodyshopId = user.id

      const response = await fetch(`/api/bodyshop/${bodyshopId}/vehicles`)
      if (response.ok) {
        const data = await response.json()
        setVehicles(data)
      }
    } catch (error) {
      console.error("Error fetching vehicles:", error)
    } finally {
      setLoading(false)
    }
  }

  const fetchClients = async () => {
    try {
      const userData = localStorage.getItem("user")
      if (!userData) return

      const user = JSON.parse(userData)
      const bodyshopId = user.id

      const response = await fetch(`/api/bodyshop/${bodyshopId}/clients`)
      if (response.ok) {
        const data = await response.json()
        setClients(data)
      }
    } catch (error) {
      console.error("Error fetching clients:", error)
    }
  }

  const handleCreateClient = async () => {
    try {
      const response = await fetch("/api/clients", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newClientForm),
      })

      if (response.ok) {
        const newClient = await response.json()
        setClients([...clients, newClient])
        setVehicleForm({ ...vehicleForm, clientId: newClient.id.toString() })
        setNewClientForm({ firstName: "", lastName: "", email: "", phone: "" })
        setIsCreatingClient(false)
      }
    } catch (error) {
      console.error("Error creating client:", error)
    }
  }

  const handleCreateVehicle = async () => {
    try {
      const userData = localStorage.getItem("user")
      if (!userData) return

      const user = JSON.parse(userData)
      const bodyshopId = user.id

      const response = await fetch("/api/vehicles", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...vehicleForm,
          bodyshopId,
        }),
      })

      if (response.ok) {
        fetchVehicles()
        setVehicleForm({ licensePlate: "", brand: "", model: "", year: "", clientId: "" })
        setIsAddCarOpen(false)
      }
    } catch (error) {
      console.error("Error creating vehicle:", error)
    }
  }

  const filteredVehicles = vehicles.filter(
    (vehicle) =>
      vehicle.license_plate.toLowerCase().includes(searchTerm.toLowerCase()) ||
      vehicle.brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
      vehicle.model.toLowerCase().includes(searchTerm.toLowerCase()) ||
      vehicle.client_name.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href="/dashboard">
                <Button
                  variant="outline"
                  size="sm"
                  className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
                >
                  ← Dashboard
                </Button>
              </Link>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-indigo-600 rounded-full flex items-center justify-center">
                  <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5H15V4C15 2.9 14.1 2 13 2H11C9.9 2 9 2.9 9 4V5H6.5C5.84 5 5.28 5.42 5.08 6.01L3 12V20C3 20.55 3.45 21 4 21H5C5.55 21 6 20.55 6 20V19H18V20C18 20.55 18.45 21 19 21H20C20.55 21 21 20.55 21 20V12L18.92 6.01Z" />
                  </svg>
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900">Gestione Mezzi</h1>
                  <p className="text-sm text-gray-600">Gestione veicoli e flotte</p>
                </div>
              </div>
            </div>
            <Dialog open={isAddCarOpen} onOpenChange={setIsAddCarOpen}>
              <DialogTrigger asChild>
                <Button className="bg-indigo-600 hover:bg-indigo-700 text-white">+ Aggiungi Veicolo</Button>
              </DialogTrigger>
              <DialogContent className="bg-white max-w-md">
                <DialogHeader>
                  <DialogTitle className="text-gray-900">Aggiungi Nuovo Veicolo</DialogTitle>
                  <DialogDescription className="text-gray-600">
                    Compila i campi sottostanti per aggiungere un nuovo veicolo al sistema.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="licensePlate" className="text-gray-700">
                      Targa
                    </Label>
                    <Input
                      id="licensePlate"
                      value={vehicleForm.licensePlate}
                      onChange={(e) => setVehicleForm({ ...vehicleForm, licensePlate: e.target.value })}
                      className="bg-white border-gray-300 text-gray-900"
                      placeholder="AB123CD"
                    />
                  </div>
                  <div>
                    <Label htmlFor="brand" className="text-gray-700">
                      Marca
                    </Label>
                    <Input
                      id="brand"
                      value={vehicleForm.brand}
                      onChange={(e) => setVehicleForm({ ...vehicleForm, brand: e.target.value })}
                      className="bg-white border-gray-300 text-gray-900"
                      placeholder="Fiat"
                    />
                  </div>
                  <div>
                    <Label htmlFor="model" className="text-gray-700">
                      Modello
                    </Label>
                    <Input
                      id="model"
                      value={vehicleForm.model}
                      onChange={(e) => setVehicleForm({ ...vehicleForm, model: e.target.value })}
                      className="bg-white border-gray-300 text-gray-900"
                      placeholder="Punto"
                    />
                  </div>
                  <div>
                    <Label htmlFor="year" className="text-gray-700">
                      Anno
                    </Label>
                    <Input
                      id="year"
                      type="number"
                      value={vehicleForm.year}
                      onChange={(e) => setVehicleForm({ ...vehicleForm, year: e.target.value })}
                      className="bg-white border-gray-300 text-gray-900"
                      placeholder="2020"
                    />
                  </div>
                  <div>
                    <Label htmlFor="client" className="text-gray-700">
                      Cliente
                    </Label>
                    <Select
                      value={vehicleForm.clientId}
                      onValueChange={(value) => setVehicleForm({ ...vehicleForm, clientId: value })}
                    >
                      <SelectTrigger className="bg-white border-gray-300 text-gray-900">
                        <SelectValue placeholder="Seleziona cliente" />
                      </SelectTrigger>
                      <SelectContent className="bg-white">
                        {clients.map((client) => (
                          <SelectItem key={client.id} value={client.id.toString()}>
                            {client.first_name} {client.last_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="mt-2 border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
                      onClick={() => setIsCreatingClient(true)}
                    >
                      + Crea Nuovo Cliente
                    </Button>
                  </div>

                  {isCreatingClient && (
                    <Card className="bg-gray-50 border-gray-200">
                      <CardHeader>
                        <CardTitle className="text-sm text-gray-900">Nuovo Cliente</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="grid grid-cols-2 gap-2">
                          <Input
                            placeholder="Nome"
                            value={newClientForm.firstName}
                            onChange={(e) => setNewClientForm({ ...newClientForm, firstName: e.target.value })}
                            className="bg-white border-gray-300 text-gray-900"
                          />
                          <Input
                            placeholder="Cognome"
                            value={newClientForm.lastName}
                            onChange={(e) => setNewClientForm({ ...newClientForm, lastName: e.target.value })}
                            className="bg-white border-gray-300 text-gray-900"
                          />
                        </div>
                        <Input
                          placeholder="Email"
                          type="email"
                          value={newClientForm.email}
                          onChange={(e) => setNewClientForm({ ...newClientForm, email: e.target.value })}
                          className="bg-white border-gray-300 text-gray-900"
                        />
                        <Input
                          placeholder="Telefono"
                          value={newClientForm.phone}
                          onChange={(e) => setNewClientForm({ ...newClientForm, phone: e.target.value })}
                          className="bg-white border-gray-300 text-gray-900"
                        />
                        <div className="flex gap-2">
                          <Button
                            type="button"
                            size="sm"
                            onClick={handleCreateClient}
                            className="bg-green-600 hover:bg-green-700 text-white"
                          >
                            Crea Cliente
                          </Button>
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => setIsCreatingClient(false)}
                            className="border-gray-300 text-gray-700 hover:bg-gray-50"
                          >
                            Annulla
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  <div className="flex gap-2 pt-4">
                    <Button
                      onClick={handleCreateVehicle}
                      className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white"
                      disabled={
                        !vehicleForm.licensePlate ||
                        !vehicleForm.brand ||
                        !vehicleForm.model ||
                        !vehicleForm.year ||
                        !vehicleForm.clientId
                      }
                    >
                      Aggiungi Veicolo
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => setIsAddCarOpen(false)}
                      className="border-gray-300 text-gray-700 hover:bg-gray-50"
                    >
                      Annulla
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto p-4">
        {/* Search and Stats */}
        <div className="mb-6">
          <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
            <div className="flex-1 max-w-md">
              <Input
                placeholder="Cerca per targa, marca, modello o cliente..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-white border-gray-300 text-gray-900"
              />
            </div>
            <div className="flex gap-4">
              <Card className="bg-white border-gray-200">
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-indigo-600">{vehicles.length}</div>
                  <div className="text-sm text-gray-600">Veicoli Totali</div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>

        {/* Vehicles List */}
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="text-gray-600">Caricamento veicoli...</div>
          </div>
        ) : (
          <div className="grid gap-4">
            {vehicles.length === 0 ? (
              <Card className="bg-white border-gray-200">
                <CardContent className="p-8 text-center">
                  <div className="text-gray-500">Nessun veicolo trovato</div>
                </CardContent>
              </Card>
            ) : (
              vehicles.map((vehicle) => (
                <Card key={vehicle.id} className="bg-white border-gray-200 hover:bg-gray-50">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center">
                          <svg className="w-6 h-6 text-indigo-600" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5H15V4C15 2.9 14.1 2 13 2H11C9.9 2 9 2.9 9 4V5H6.5C5.84 5 5.28 5.42 5.08 6.01L3 12V20C3 20.55 3.45 21 4 21H5C5.55 21 6 20.55 6 20V19H18V20C18 20.55 18.45 21 19 21H20C20.55 21 21 20.55 21 20V12L18.92 6.01Z" />
                          </svg>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">{vehicle.license_plate}</h3>
                          <p className="text-sm text-gray-600">
                            {vehicle.brand} {vehicle.model} ({vehicle.year})
                          </p>
                          <p className="text-sm text-gray-500">Cliente: {vehicle.client_name}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-gray-500">Ultimo servizio</p>
                        <p className="text-sm font-medium text-gray-900">{vehicle.last_service || "N/A"}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  )
}
