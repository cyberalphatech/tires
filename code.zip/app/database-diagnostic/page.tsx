"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Database, CheckCircle, XCircle, AlertTriangle, Wrench } from "lucide-react"

interface TableInfo {
  name: string
  exists: boolean
  columns?: string[]
  missingColumns?: string[]
  foreignKeys?: string[]
}

interface DiagnosticResult {
  connected: boolean
  error?: string
  tables: TableInfo[]
  missingTables: string[]
  summary: {
    totalTables: number
    existingTables: number
    missingTables: number
    issuesFound: number
  }
}

export default function DatabaseDiagnosticPage() {
  const [diagnostic, setDiagnostic] = useState<DiagnosticResult | null>(null)
  const [loading, setLoading] = useState(false)
  const [fixing, setFixing] = useState<string | null>(null)

  const runDiagnostic = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/database-diagnostic")
      const data = await response.json()
      setDiagnostic(data)
    } catch (error) {
      console.error("Diagnostic failed:", error)
      setDiagnostic({
        connected: false,
        error: "Failed to connect to diagnostic API",
        tables: [],
        missingTables: [],
        summary: { totalTables: 0, existingTables: 0, missingTables: 0, issuesFound: 1 },
      })
    } finally {
      setLoading(false)
    }
  }

  const fixTable = async (tableName: string) => {
    setFixing(tableName)
    try {
      const response = await fetch("/api/database-diagnostic/fix-table", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tableName }),
      })

      if (response.ok) {
        // Re-run diagnostic after fixing
        await runDiagnostic()
      } else {
        alert("Failed to fix table")
      }
    } catch (error) {
      console.error("Fix failed:", error)
      alert("Failed to fix table")
    } finally {
      setFixing(null)
    }
  }

  useEffect(() => {
    runDiagnostic()
  }, [])

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Database className="h-8 w-8" />
            Database Diagnostic
          </h1>
          <p className="text-muted-foreground mt-2">Comprehensive database health check and repair tool</p>
        </div>
        <Button onClick={runDiagnostic} disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Running Diagnostic...
            </>
          ) : (
            "Refresh Diagnostic"
          )}
        </Button>
      </div>

      {diagnostic && (
        <>
          {/* Connection Status */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {diagnostic.connected ? (
                  <CheckCircle className="h-5 w-5 text-green-500" />
                ) : (
                  <XCircle className="h-5 w-5 text-red-500" />
                )}
                Database Connection
              </CardTitle>
            </CardHeader>
            <CardContent>
              {diagnostic.connected ? (
                <p className="text-green-600">✅ Successfully connected to MySQL database</p>
              ) : (
                <div className="space-y-2">
                  <p className="text-red-600">❌ Failed to connect to database</p>
                  {diagnostic.error && (
                    <Alert>
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>{diagnostic.error}</AlertDescription>
                    </Alert>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Summary */}
          <Card>
            <CardHeader>
              <CardTitle>Database Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold">{diagnostic.summary.totalTables}</div>
                  <div className="text-sm text-muted-foreground">Required Tables</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">{diagnostic.summary.existingTables}</div>
                  <div className="text-sm text-muted-foreground">Existing Tables</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-red-600">{diagnostic.summary.missingTables}</div>
                  <div className="text-sm text-muted-foreground">Missing Tables</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600">{diagnostic.summary.issuesFound}</div>
                  <div className="text-sm text-muted-foreground">Issues Found</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Table Details */}
          <Card>
            <CardHeader>
              <CardTitle>Table Analysis</CardTitle>
              <CardDescription>Detailed analysis of required tables and their structure</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {diagnostic.tables.map((table) => (
                  <div key={table.name} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold">{table.name}</h3>
                        <Badge variant={table.exists ? "default" : "destructive"}>
                          {table.exists ? "EXISTS" : "MISSING"}
                        </Badge>
                      </div>
                      {!table.exists && (
                        <Button size="sm" onClick={() => fixTable(table.name)} disabled={fixing === table.name}>
                          {fixing === table.name ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Creating...
                            </>
                          ) : (
                            <>
                              <Wrench className="mr-2 h-4 w-4" />
                              Create Table
                            </>
                          )}
                        </Button>
                      )}
                    </div>

                    {table.exists && table.columns && (
                      <div className="mt-2">
                        <p className="text-sm text-muted-foreground mb-1">Columns:</p>
                        <div className="flex flex-wrap gap-1">
                          {table.columns.map((column) => (
                            <Badge key={column} variant="outline" className="text-xs">
                              {column}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {table.missingColumns && table.missingColumns.length > 0 && (
                      <div className="mt-2">
                        <p className="text-sm text-red-600 mb-1">Missing Columns:</p>
                        <div className="flex flex-wrap gap-1">
                          {table.missingColumns.map((column) => (
                            <Badge key={column} variant="destructive" className="text-xs">
                              {column}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {table.foreignKeys && table.foreignKeys.length > 0 && (
                      <div className="mt-2">
                        <p className="text-sm text-muted-foreground mb-1">Foreign Keys:</p>
                        <div className="flex flex-wrap gap-1">
                          {table.foreignKeys.map((fk) => (
                            <Badge key={fk} variant="secondary" className="text-xs">
                              {fk}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Missing Tables */}
          {diagnostic.missingTables.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-red-600">Missing Tables</CardTitle>
                <CardDescription>These tables are required but don't exist in your database</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {diagnostic.missingTables.map((tableName) => (
                    <div key={tableName} className="flex items-center justify-between p-2 border rounded">
                      <span className="font-medium">{tableName}</span>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => fixTable(tableName)}
                        disabled={fixing === tableName}
                      >
                        {fixing === tableName ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Creating...
                          </>
                        ) : (
                          <>
                            <Wrench className="mr-2 h-4 w-4" />
                            Create
                          </>
                        )}
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  )
}
