"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function CustomerLoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const router = useRouter()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    try {
      const response = await fetch("/api/auth/customer-login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      })

      const data = await response.json()

      if (response.ok) {
        // Store customer data in localStorage
        localStorage.setItem("customer", JSON.stringify(data.customer))

        // Redirect to customer dashboard
        router.push(`/customer/${data.customer.id}/dashboard`)
      } else {
        setError(data.error || "Errore durante il login")
      }
    } catch (error) {
      console.error("Customer login error:", error)
      setError("Errore di connessione. Riprova più tardi.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-white flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-lg border-gray-200">
        <CardHeader className="text-center space-y-4">
          <div className="w-16 h-16 mx-auto">
            <img src="/images/tires-pro-logo.png" alt="Tires Pro" className="w-full h-full object-contain" />
          </div>
          <CardTitle className="text-2xl font-bold text-gray-800">Accesso Cliente</CardTitle>
          <CardDescription className="text-gray-600">
            Accedi al tuo account per gestire i tuoi pneumatici
          </CardDescription>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            {error && (
              <div className="p-3 text-sm text-red-600 bg-red-50 border border-red-200 rounded-md">{error}</div>
            )}

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="la-tua-email@esempio.it"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="h-12"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="h-12"
              />
            </div>

            <Button
              type="submit"
              className="w-full h-12 text-lg font-semibold bg-teal-600 hover:bg-teal-700 text-white"
              disabled={isLoading}
            >
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  Accesso in corso...
                </div>
              ) : (
                "Accedi"
              )}
            </Button>
          </form>

          <div className="mt-4 p-3 bg-gray-50 border border-gray-200 rounded-md">
            <p className="text-sm text-gray-800 font-medium">Account di prova:</p>
            <p className="text-xs text-gray-600">Email: mario.rossi@email.com</p>
            <p className="text-xs text-gray-600">Password: customer123</p>
          </div>

          <div className="mt-6 text-center space-y-4">
            <Link href="/customer-register" className="text-sm text-teal-600 hover:underline font-medium">
              Non hai un account? Registrati qui
            </Link>

            <div className="border-t pt-4">
              <Link href="/auth/login" className="text-sm text-gray-600 hover:underline">
                Accesso Staff →
              </Link>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
